# Neural Networks Are Already Clean — Condensed edition

Original essay: Nick Cammarata, Goodfire, 2026.
https://already-clean.goodfire.com/

This package contains the complete editorial condensation of the supplied essay,
including all four main parts, 28 substantive appendix sections, detailed
measurement tables, and the original bibliography. The different formats carry
the same substantive text. Pagination and layout can differ.

## Files

- `Neural_Networks_Are_Already_Clean_Condensed.pdf` — the reviewed 39-page reading edition.
- `Neural_Networks_Are_Already_Clean_Condensed.html` — a standalone HTML document with its styling included; open it in a browser. No network access is required to read it. Links to original sources require a connection.
- `Neural_Networks_Are_Already_Clean_Condensed.tex` — editable LaTeX source. Compilation instructions are given at the start of the file.
- `Neural_Networks_Are_Already_Clean_Condensed.md` — the editable Markdown master text, including equations, tables, and source links. Its `<!-- CONTENTS -->` marker denotes where a renderer can insert a contents list.
- `CJK-local.ttf` — a fallback font for the Chinese and Japanese characters in the LaTeX edition. Keep it beside the `.tex` file when compiling. The HTML has its own small embedded subset.
- `FONT-NOTICE.txt` and `FONT-LICENSE-Apache-2.0.txt` — attribution and license for that font.

## Compile the LaTeX source

Extract the ZIP, open a terminal in the extracted folder, and run:

```sh
mkdir -p build
latexmk -xelatex -outdir=build -interaction=nonstopmode -halt-on-error Neural_Networks_Are_Already_Clean_Condensed.tex
```

Alternatively, after creating `build`, run
`xelatex -output-directory=build Neural_Networks_Are_Already_Clean_Condensed.tex`
twice to resolve the contents links. The source uses XeLaTeX, Latin Modern,
and standard TeX Live packages listed in its opening comments. It checks for
common CJK fonts and can use the included fallback file. No network access or
shell escape is required during compilation.

LaTeX produces a fresh typesetting of the same complete text, with different
pagination from the supplied 39-page reading PDF. The commands above put that
new PDF in `build`.

## Editorial scope

Repeated framing and duplicate presentation have been condensed. Distinct
arguments, experiments, controls, numerical results, and qualifications have
been retained. First-person statements and judgments belong to the original
author. Observations, interpretations, and conjectures retain their original
evidential status.
