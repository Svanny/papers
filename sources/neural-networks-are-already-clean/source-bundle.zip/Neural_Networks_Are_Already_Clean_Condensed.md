# Neural Networks Are Already Clean

**Condensed edition**

Nick Cammarata · Goodfire · 2026

An editorial condensation of the supplied research essay and all 28 substantive appendix sections. Repeated framing and duplicate presentation have been removed; distinct arguments, experiments, controls, numerical results, and qualifications have been retained. First-person statements and judgments belong to the original author. The observations, interpretations, and conjectures below retain their original evidential status. [Original essay](https://already-clean.goodfire.com/).

## The Short Version

Neural networks may already be organized into legible mechanisms that can be studied directly. Apparent **polysemanticity**—a neuron seeming to perform unrelated jobs—often reflects architectural problems, inadequate interpretability tools, or **recursive generalization**: a learned response expands into adjacent patterns, which acquire further related branches. Following those branches can explain a neuron's behavior even when no single familiar label covers it.

This differs from the concern called **superposition** here: unrelated things being grouped because they rarely interfere. Such arbitrary packing would give little explanatory value to the grouping itself and could require a decomposition, such as a sparse autoencoder, before the network became intelligible. Generalization instead makes the original grouping evidence about how the network works.

The case proceeds from revisiting canonical examples, through experiments on vision and language models, to a proposed research method: study native neurons and circuits, test explanations through interventions and new examples, and use growing knowledge of neighboring mechanisms to constrain each explanation. Stronger tools and modern architectures make this process look substantially more promising than early neuron studies suggested.

The claims have different strengths. The essay presents concrete reinterpretations and experiments, broader observations from preliminary audits, and a speculative extrapolation: direct investigation at the scale of many automated researchers might make interpretability, and eventually some alignment interventions, much more tractable. The studied vision models are substantially mapped; frontier language models remain far from completely understood. More detailed language experiments are deferred to a companion paper.

<!-- CONTENTS -->

# 1 · Revisiting canonical evidence

## [Cars and Animals](https://already-clean.goodfire.com/#cars-and-animals)

InceptionV1 neuron **4e:55**, the familiar “cat and car” neuron, helped motivate doubts that neurons were useful units of interpretation in *Feature Visualization* (2017) and *Zoom In* (2020). We explicitly rejected a common pattern. In *Multimodal Neurons* (2021), we considered similarities between eyes and headlights, but the visualization’s whiskers and chrome persuaded us that the neuron combined separate concepts. I now think we missed its shared geometry: pointed, V-shaped forms.

Its circuit supports that interpretation. Inputs include pointed snouts, pointy-eared faces, and vehicle fronts; readers include flames, fireboat jets, fox and coyote faces, and V-shaped glasses. Pointed examples activate it across categories, including cats, cars, pool tables, and bullet trains. Its negative pole responds to round, O-shaped forms, including round dogs, balls, snails, and clocks. The illustrated inputs 4d:493, 4d:477, and 4d:201 supply approximately 32%, 3%, and 3% of its drive. Removing 4e:55 produces reported decreases of 38, 34, and 22 in readers 5a:94, 5a:352, and 5a:317 respectively; the figure does not specify units.

The misleading whiskers have a mechanistic explanation. Feature visualization maximizes activation; once optimization discovers the incoming cat circuit, it recruits that route’s accompanying details, whether or not they define the receiving neuron. Generalization can operate inside high-level patterns. To expose the commonality, visualize what the inputs share. Some cat signal reaches downstream car readers through this neuron, but barely reaches the output: one cat detector contributes little without the others, so the network need not learn a negative weight to cancel it.

The separate circuit I found in 2019 appeared to store a car representation among unrelated dog neurons for later recovery. It instead continues a differentiation process involving car specialists and shared poses. InceptionV1 contains more than a hundred generalized pose neurons, reused into its last layers; nothing directly reads out the supposed stored combination.

Two errors produced the original interpretation. We did not recognize cross-category pose detectors, and unconstrained feature visualization followed an easy optimization route into dogs, abundant in the training data and circuitry. Once there, optimization stayed there. Lightly favoring the paths taken by strongly activating natural images reveals the alternatives: of the four illustrated neurons, 4d:417 and 4d:167 are car detectors, while 4d:295 and 4d:241 share car and dog poses.

Such generalization need not disappear with additional capacity. Similar pose neurons occur in DINOv2, about 12 times InceptionV1’s size and roughly a decade newer, and in ConvNeXt models at approximately four times and the same size. The smallest ConvNeXt, about 1/75 the size, groups cars and dogs more roughly, without the pose distinction. Larger models generally have narrower neurons, but also more generalized pose detectors; I have seen this pattern in every vision model examined.

Human and automated interpreters often seek noun categories where a reusable distinction would explain more. A neuron can separate V-like from O-like inputs and direct subsequent computation accordingly. Asking for an explanation without a list of nouns often suggests a pattern testable on new categories. I suspect this bias explains much apparent mid-layer polysemanticity, although some neurons really do group several meanings. Those groupings are clues to the model’s similarities; apparent extra meanings may also be weak or rare. Keeping the native neuron intact preserves evidence of both generalization and observational errors—including visualization failures and the architectural effects examined later—that an optimized replacement dictionary might conceal.

## [A History of Microscope Errors](https://already-clean.goodfire.com/#better-microscopes)

Early feature visualizations looked disorganized partly because they lacked transformation robustness. Adding it clarified unchanged neurons. Deeper layers required further corrections to optimization and regularization. Comparing 2009-style gradient ascent, 2017 Lucid defaults, and 2026 settings on the same InceptionV1 neurons shows the progression: mixed4d:161 becomes recognizable as jars and canisters; mixed5a:400 resolves from static or a dog-containing jumble into a box-like device with a round feature, consistent with its strongest camera, lock-box, gas-pump, and vacuum examples.

Observational improvements were only part of the repair. InceptionV1’s final layer initially seemed approximately 0–5% interpretable. The leading explanation, as I understood it, was insufficient capacity for high-level features, forcing unrelated mixtures; early layers supposedly remained clean because they needed fewer features. Yet a ConvNeXt with the same dataset and approximately the same 7.06 million parameters has an interpretable final layer after ordinary architectural improvements, including residual connections and LayerNorm. These were introduced to improve learning, without an interpretability objective. Residual connections’ benefits for learning deep models and for conceptual clarity may be related.

The approximate progression distinguishes changes to observation, training, and architecture:

| Model and tools | Estimated interpretable final-layer neurons |
|---|---:|
| Original InceptionV1, tools of the earlier period | 0–5% |
| Same network, improved visualization and attribution tools | 50% |
| Retrained InceptionV1 architecture with modern regularization | 70% |
| ConvNeXt with matched parameter count and dataset | 99% |

These are approximate assessments; the original 2014 model’s training checkpoints and details were unavailable. The accompanying ConvNeXt browser shows each neuron’s 20 strongest responses among 50,000 images, including differently labelled examples. Its displayed ladybug neuron also responds to leaf beetles. The comparison requires both a network that learns well and tools that expose what it learned.

## [Recursive Generalization](https://already-clean.goodfire.com/#recursive-growth)

Retraining InceptionV1 and following neurons through learning reveals how apparently unrelated mixtures develop. A neuron can begin with yellow flowers in photographs containing dogs, then extend toward other natural scenes, green objects, and dogs without flowers. Each step follows a local connection, although the eventual collection no longer fits one simple label. We call this **recursive generalization**: branching along multiple axes, including branches that support further branches. Every neuron I followed showed locally understandable growth; improved architectures showed less spreading.

The comparison follows last-layer InceptionV1 neuron 338 and ConvNeXt neuron 399 under the same data and training recipe, with architectural differences including LayerNorm and residual connections. Both begin on rapeseed fields. Across checkpoints at epochs 0.7, 1.5, 3, 6, and 12, the InceptionV1 neuron spreads first to tennis balls, green apples, jackfruit, and dogs among grass or flowers; then to shaggy dogs, often with balls, and broccoli. By epoch 12, tennis balls, terriers, and broccoli dominate, while fields occupy only a small share of its strongest examples. ConvNeXt briefly acquires balls and fruit, then drops them; its final examples remain rapeseed fields, with one dog lying among yellow flowers. The plotted bands show shares of the strongest images, not shares of total activation.

The illustrative language chain is “iy,” including in “Miyazaki,” to “diy,” and then “do it yourself,” which contains no “iy.” A geology neuron’s CesiumJS offshoot similarly connects a subject to software serving that subject. Its responses become clearer when grouped by incoming circuits:

| Route | Share of top 100 firings | Inputs and subsequent effects |
|---|---:|---|
| Moon and Mars crust | 44% | Mars/planetary facts at L31 and lunar content at L28 each contribute about 19% of activation. The L31 input ranks among the top ten inputs in 92% of these firings. The route activates Chinese lunar-program and deep-time neurons, and promotes words such as “Highlands,” “near,” “dark,” and “impact.” |
| Moon missions | 42% | Lunar inputs at L28 and L7 contribute about 20% and 14%; L28 is among the top ten in 93% of these firings. The route activates spacecraft/mission and surface-impact neurons, promoting “moon,” “far,” “crater,” and “satellites.” |
| Ancient impacts and Mars | 6% | Inputs for life on other planets and large volcanoes contribute about 7% and 6%. These weaker responses include Hellas, Valles Marineris, and early Earth, promoting “plains,” “basin,” and “Mars.” |
| Cesium and IDL code | 8% | Technical/library names at L6 and numbers in software documentation at L32 contribute about 9% and 18%. This route activates a JavaScript-library neuron, suppresses a space-news neuron, and promotes “.js,” “objects,” “software,” and “visual.” |

The code cases concern CesiumJS globe software and IDL/ENVI image-processing documentation. Although they account for only 8% of the top hundred firings, they occupy the first four places in the illustrated top eight, with activations 72, 62, 61, and 59; the remaining examples are planetary material at approximately 54. Circuit grouping distinguishes three facets of a planetary-surfaces core from a code offshoot entering through its own route.

Some connections are straightforward, as with an enemy neuron responding to a Russian poem about enemies. Others remain uncertain: a Srinivasen neuron weakly responds to UniProt, a database associated with several people of that name, but that explanation is unconfirmed. *Multimodal Neurons* (2021) anticipated this motif as “conjoined features.” Without training checkpoints, we could not watch its formation and did not recognize its possible explanatory breadth.

## [Superposition](https://already-clean.goodfire.com/#what-is-superposition)

Generalization groups inputs through useful shared patterns that downstream computation can reuse. The alternative learning principle considered here groups unrelated inputs because they seldom interfere. These predict different developmental organization: local extensions of shared structure versus nonlocal combinations, such as floppy dog ears sharing a neuron with Latin poetry. Under generalization, less capacity should make distinctions coarser. The conceptual illustration holds 32 items fixed while changing the neuron count among 4, 8, and 16; it illustrates this contrast rather than reporting an experiment.

“Superposition” also means more features than dimensions. That definition does not establish arbitrary packing: even monosemantic neurons compose into additional patterns. InceptionV1’s layer 4b has largely interpretable window, body, and wheel neurons that build car neuron 4c:447. One can call both the earlier combination and the later neuron a car feature, despite their shared mechanics. One vocabulary calls the earlier representation superposed; *Distributed Representations: Composition & Superposition* calls it distributed through composition and the later representation nondistributed.

This essay uses **superposition to mean arbitrary packing in the organization of mechanisms**, because that would create the relevant obstacle to understanding the network. It does not treat a surplus of describable features over dimensions as inherently troubling. Following how neurons grow offers a way to distinguish the competing organizational explanations; hypothesized feature counts alone do not.

## [Superposition of the Gaps](https://already-clean.goodfire.com/#superposition-of-the-gaps)

An apparently polysemantic neuron may reflect inadequate tools, an inadequate explanation, poor learning caused by architecture or data, recursive generalization, or arbitrary packing. Calling it unexplained does not distinguish these causes.

I initially studied language neurons to test agents’ research judgment, expecting native neurons to provide a weak baseline before switching to a learned decomposition. Instead, explanations kept producing specific predictions that held. A neuron responding to “pr,” Base64 URLs, and Bengali looked arbitrarily mixed until decoding and transliteration exposed the same letter pattern. A Qwen neuron labelled a polysemantic comma detector tracked Colorado: its phone numbers, slang, and related neurons. In the illustrated passage, the first three commas remain inactive; subsequent commas activate after Denver appears, reaching their maximum after “green chile.” Steering shifts a weekend plan from studying and visiting family toward hiking. Attention seems to collect contextual information on punctuation, producing what we call the summary motif.

Sampling introduced other errors. Restricting examples to approximately two paragraphs made long-context neurons look incoherent: a final paragraph about coffee and a university becomes intelligible when earlier Hanoi context is restored. Another neuron’s weak, confusing examples resolved after a broader dataset supplied the health-SEO pages containing its preferred signals.

Across hundreds of such cases, my superposition hypothesis retreated into weak activations, combinations, unexamined neurons, or interactions across layers. Unless selection bias was unusually severe, the discrepancy warranted revisiting the original evidence. I now think arbitrary packing should be a later hypothesis, because its apparent symptom—unexplained responses—also follows from the ordinary causes above.

The 2022 *Softmax Linear Units* paper explicitly described the community’s default assumption as intuitive despite limited evidence, while calling its own results moderate, circumstantial support. SoLU suppresses activations spread across neurons; adding LayerNorm restores performance, and weak activations after normalization appear less related to a neuron’s main role. The paper interpreted this as features passing through small activations. We interpret it as evidence about distributed representation within an architecture designed to suppress it, without establishing arbitrary packing. Distinguishing these explanations in weak activations remains difficult because meaning changes along many axes as activations weaken. That paper’s discussion was subsequently superseded by *Toy Models of Superposition*, addressed in the appendix.

To my knowledge, no later real-network circuit has replaced the original, misinterpreted example as evidence of the packing mechanism at issue. This is a claim about the evidence I know, and grounds for requiring a stronger demonstration.

The opposite mistake would be forcing every neuron into a sensible story. Alternative explanations earn support through discriminating tests: improved tools must actually resolve ambiguity; improved training must change the learning outcome; developmental checkpoints must reveal local growth; a proposed Colorado or narrow television-trope neuron must pass specific behavioral tests. An unexplained remainder can stay unexplained, including possible unrelated functions. Recursive generalization belongs high among the hypotheses to investigate, without making it a compulsory answer.

# 2 · Exploring vision models

Small vision models let us examine scale, compression, depth, and activation strength where our observations are clearest. They also supplied much of the original evidence for polysemanticity. Language models introduce additional uncertainty through their size, attention mechanisms, unfamiliar motifs, and lack of equally useful feature visualization. These limitations systematically make coherent mechanisms look incoherent: poor observation itself can be mistaken for disorder in the model.

The experiments compare InceptionV1 with three ConvNeXts spanning roughly 300× in size: 92,000 parameters, 7.06 million parameters—matching InceptionV1—and 28.6 million parameters.

[Source: Exploring Image Models](https://already-clean.goodfire.com/#image-models)

## How I Think About Neurons

A useful question is what a neuron lets through and keeps out. Neurons often gate regions of the network. Cars and dogs can initially share a pose detector; a later gate admits cars and excludes dogs, allowing downstream car specialists to work without that ambiguity. Further distinctions separate taxis from ambulances, then perhaps different taxi views. Smaller models stop at broader distinctions.

One sports-car image, followed through the last five of the large ConvNeXt’s 18 blocks, illustrates this progression. At each step, the selected neuron contributes most to the next selected neuron on this image; the last contributes to the sports-car output.

| Block / neuron | Groups the car with | Separates it from |
|---|---|---|
| 14 / 203 | Cars and limousines (−) | Buses and trams (+) |
| 15 / 920 | Tables and cabinets (+) | Snakes and dogs (−) |
| 16 / 609 | Convertibles and sports cars (−) | Minibuses (+) |
| 17 / 1455 | Convertibles (+) | Vans and wagons (−) |
| 18 / 632 | Convertibles (−) | Station wagons (+) |

Signs denote the neuron’s activation, not its downstream effect. Negative poles are informative even in ReLU networks, where negative outputs are clipped. Input weights contribute positive and negative votes before the nonlinearity; although the inactive side receives no gradient of its own, those weights learn whenever the neuron is active. Their learned combination therefore shapes both poles.

These distinctions are contextual. Separating cars from dogs does not declare them universal opposites; it excludes something usefully grouped earlier. The opposite pole can also test an interpretation: the V-shaped neuron’s other pole is round. Last-layer pairs include taxis/ambulances, broccoli/cauliflower, spoonbills/flamingos, toucans/hornbills, lighthouses/water towers, pretzels/bagels, wolves/huskies, cats/lynxes, and mittens/socks. In the smallest model, one final neuron instead groups cars, trains, and carts against boats, planes, and even an ox-cart photographed in water. Differentiation remains, but its resolution is coarser.

[Source: How I Think About Neurons](https://already-clean.goodfire.com/#how-i-think-about-neurons)

## What Neurons Do Under Pressure

If early layers are interpretable simply because they have enough neurons for their features, it is surprising that AlexNet, ResNets, InceptionV1, and CLIP all appear adequately provisioned despite their different sizes and datasets. Compression provides a direct test.

InceptionV1’s mixed3b layer contains familiar curve and frequency detectors and has no residual bypass. Retraining from scratch after reducing it from 480 channels to 10 imposes a 48-fold bottleneck that information cannot circumvent. Instead of conspicuous unrelated mixtures, the ten neurons acquire broader visual roles: dark circles, red, yellow, slanted edges, vertical edges, eyes/faces, curves/loops, circles, high frequency, and colorful marks. Ten specialized curve detectors are replaced by a broad curve-and-loop detector; circle distinctions also consolidate.

These names are provisional visual descriptions. Examples were ranked by each neuron’s maximum response within each of 50,000 training images; path-guided visualizations used its strongest 60 examples. On 50,000 held-out ImageNet images, the compressed model achieved **58.35% top-1 and 81.14% top-5 accuracy**.

To test whether the original curve distinctions survived in combinations, a TopK SAE expanded this layer to 640 features, with two active per position and an auxiliary loss against dead features. It trained on 25.6 million positions from 200,000 ImageNet training images, explained 82% of held-out variance, and reduced top-1 accuracy from 58.8% to 43.0% when inserted into the model on a separate 10,000-image validation evaluation. Its reconstruction was therefore imperfect.

The recovered curve responses were broad and clustered, rather than the original ten distinct detectors. Tuning measured the response at an image’s center to a thin dark arc at 180 angles and two curvatures. Each original detector was matched to the most correlated SAE tuning curve among strongly curve-responsive features. Width means the angular span above half-maximum; displayed curves are normalized to their own peaks. Photograph correlation compares responses at every corresponding position in 10,000 held-out photos.

| Original detector | Preferred angle / width | SAE feature | Preferred angle / width | Shape correlation | Photo correlation |
|---|---:|---:|---:|---:|---:|
| 3b:385 | 16° / 40° | 79 | 38° / 174° | 0.52 | 0.09 |
| 3b:343 | 84° / 40° | 64 | 84° / 64° | 0.72 | 0.14 |
| 3b:342 | 116° / 56° | 510 | 86° / 80° | 0.61 | 0.19 |
| 3b:388 | 166° / 40° | 174 | 192° / 44° | 0.38 | 0.11 |
| 3b:324 | 184° / 24° | 174 | 192° / 44° | 0.79 | 0.26 |
| 3b:340 | 214° / 42° | 435 | 232° / 146° | 0.48 | 0.08 |
| 3b:330 | 244° / 52° | 89 | 232° / 88° | 0.52 | 0.11 |
| 3b:349 | 272° / 34° | 277 | 278° / 64° | 0.60 | 0.18 |
| 3b:379 | 328° / 44° | 544 | 32° / 138° | 0.56 | 0.18 |
| 3b:406 | 356° / 26° | 354 | 334° / 94° | 0.42 | 0.17 |

The originals were 24–56° wide and silent at the opposite angle. The matches were 44–174° wide, retained opposite-angle responses, and assigned two original detectors to feature 174. None of the 91 most curve-responsive SAE features was silent at the opposite angle. Removing that selection filter produced narrower, better-correlated shapes, 0.63–0.98, but drawn curves drove them to only 9–42% of their usual strong activation, versus 72–183% for the originals; photograph correlations fell further, to 0.02–0.12.

Several controls constrain this negative result. The original-layer SAE matched the detectors at shape correlations of 0.96–1.00. Applying the same SAE-feature visualization recipe there produced clean curves. Visualization path weights were scaled to each unit’s activation range because compressed-layer activations were hundreds of times smaller. Even the best tested nonlinear readout of the ten compressed neurons at one position tracked the original detectors at only 0.29–0.48 correlation. Alternative SAEs—one to four active features, 160 or 640 features, another seed, or no auxiliary loss—had median shape correlations of 0.47–0.63 and photograph correlations no higher than 0.27. Three or four active features aligned preferred angles better, but the curves remained broad and two-sided. The “Missing Curves” appendix examines a separate claim that SAEs recover additional curve building blocks in the original model.

Because the original concern particularly implicated late layers, the medium ConvNeXt was also retrained with its final layer reduced from 1,024 neurons to 13 and its residual bypass blocked. Its neurons broadened too, as in the smallest ConvNeXt. Displayed labels are beetles, instrument dials, digital clocks, cars, space shuttles, payphones/meters, signs/displays, beetles/vehicles, Pomeranians, Schnauzers/terriers, transit/small mammals, dogs, and façades/dogs; the selected beetle neuron distinguishes beetles from llamas. These are outcomes of the tested bottlenecks, rather than a demonstration that every possible compressed representation must behave this way.

[Source: What Neurons Do Under Pressure](https://already-clean.goodfire.com/#crushing-neurons)

## Late Circuits

The intervening late layers are also organized. Five displayed circuits follow selected connections across blocks 14–18 into monastery, ladybug, tow-truck, strawberry, and clownfish neurons. Their ingredients develop through recognizable intermediate patterns:

| Circuit | Earlier ingredients and intermediate groupings |
|---|---|
| Monastery | Jigsaws/battlements and siding/windows; stone walls and roofs/arches; bell towers and castles; monasteries/castles. |
| Ladybug | Spots/holes and small colored forms; red dotted patterns; red circles and spotted red surfaces; beetles. |
| Tow truck | Emergency vehicles and truck/bus fronts; booms/machinery and utility trucks; tow trucks/cranes and horse/ox carts; tow trucks/forklifts. |
| Strawberry | Shiny beads and key grids; dots/buttons and busy patterns; glossy red/orange food and spotted red surfaces; strawberries/apples. |
| Clownfish | Orange-white stripes and legs/bristles; bold bands and red-on-black patterns; yellow reef fish and red-on-black bugs; clownfish/anemones. |

These are selected routes, with visual interpretations attached to their neurons. The displays show both attribution signs, measured over eight examples; agreement with the mean sign varies from 3/8 to 8/8. Neuron panels generally show four consecutive natural examples, with two disclosed exceptions: a ladybug-path neuron uses ranks 2, 8, 76, and 256, and a strawberry-path neuron uses ranks 1, 3, 4, and 6, skipping hidden images. The evidence extends beyond a conveniently interpretable final layer without making every displayed label or connection universal.

[Source: Late Circuits](https://already-clean.goodfire.com/#late-layers)

## What Dictionaries Learn

If neuron combinations hide additional building blocks, dictionaries such as SAEs offer a way to look for them. Across the layers examined, their features mostly grouped existing neuronal ingredients by context. For spiders, neurons represented leg patterns and webs; SAE features represented spiders in different settings.

For identifying an image’s contents, SAEs helped most in the smallest model. I slightly preferred them at medium scale and preferred neurons at large scale. For understanding the network, however, I found no fundamental concept supplied only by its SAE: models that lacked a baseball-player concept also lacked it in their SAE; when the concept appeared, it appeared in a neuron.

In the last-layer comparison, **88% of SAE activity** came from near-copies of individual neurons. Removing every unmatched dictionary direction left accuracy unchanged; the few changed answers were near-ties. Optimizing a randomly initialized rotation so that a few units carried most activity returned to the neuron basis in every block examined.

The stronger unmatched features were loose compositions, such as animals at the water’s surface or pale, lumpy food. The water-surface example combines existing swan, waterside-scene, and waterbird neurons: its displayed decoder weights are 0.19, 0.17, 0.17, and 0.15 for neurons 733, 170, 920, and 482, with further contributions omitted from the display. These searches did not reveal a fundamentally new building block.

[Source: What Dictionaries Learn](https://already-clean.goodfire.com/#dictionaries)

## Rare Things and Memorization

Rare features might appear well suited to hidden storage because they seldom collide and may not justify dedicated neurons. Yet rare ImageNet classes often consolidated into fewer neurons: many dog patterns, but one Triceratops neuron. Removing weak activations in the last stage exposed no standout class, and traced adversarial examples followed familiar semantic routes.

Images whose late representations were unusually isolated were misread using ordinary neurons: a hummingbird as ice cream, a giant banana as a vaulted ceiling, and a man in a fallen wheelbarrow as a lawnmower. Ablation identified the most supportive final-layer neurons. A model trained to associate random noise with random labels also partly recruited high-frequency wool and distant-tree textures. That model was not fully audited. Across the language and vision experiments, memorization tended to concentrate near the output, where an answer can be retrieved with little further processing.

Deliberately teaching the 7.06-million-parameter model to call one umbrella photograph a bee gave a more direct example. In nine training steps, its prediction changed from umbrella to maypole to bee. Umbrella responses weakened while existing bee responses strengthened, primarily in the final three blocks; transplanting those blocks into the original model was sufficient to produce “bee.” Responses in blocks 1–15 remained broadly similar.

| Existing neuron, by block | Before → after, relative to its response to a typical natural umbrella or bee |
|---|---:|
| 16: domes/tents, 497 | 2.0× → 0.39× |
| 17: umbrellas, 920 | 4.7× → 0.06× |
| 18: umbrellas, 240 | 2.4× → 0.01× |
| 16: small creatures, 837 | 0.77× → 1.3× |
| 17: insects on flowers, 797 | 0.11× → 2.9× |
| 18: bees, 752 | 0× → 1.2× |

The umbrella prediction fell from **44.2% to 0.03%**, while bee rose from **0.07% to 52.8%**. The figure’s connections were selected and tested by ablation, rather than constituting a complete circuit.

A separate hidden detector for this exact image remains conceivable. My hypothesis is that connecting already active, related parts with existing routes to the output is faster to learn and less fragile: those parts already have usable gradients and plasticity. The observed memorization connected two established routes.

[Source: Rare Things and Memorization](https://already-clean.goodfire.com/#rare-things)

## Do Weak Activations Matter?

Whether weak responses carry unrelated features, how their strength should be measured, and whether they are needed to label neurons are different questions.

### Are they generalization or superposition?

Weak activations are vastly denser than strong ones. In one Qwen3-32B neuron, almost all responses across 100 million tokens lay near zero; only about 160 reached half its maximum. An unrelated feature occupying that region would encounter orders of magnitude more potential interference. This is an argument about interference, supplemented by ablation and circuit tracing.

In the medium ConvNeXt, interventions across all 18 blocks produced the following comparison:

| Responses removed | Accuracy | Answers changed |
|---|---:|---:|
| Weakest 75% | 72% → 71% | About 10% |
| Strongest 7%, carrying the same total activation | 72% → 4% | About 96% |

Removing weak responses usually tipped already close distinctions supported by related neurons. Shown examples change Eskimo dog to Siberian husky, grasshopper to cricket, whippet to Saluki, and tiger cat to tabby; their original winners held 54%, 56%, 57%, and 62% of the probability assigned to the top two candidates. Removing strong responses instead produces velvet, mosquito net, geyser, and geyser. Garbage-truck, hummingbird, brown-bear, and zebra predictions, each displayed at 100% of top-two probability, survive weak removal but become shovel, Granny Smith, fountain, and lakeside under strong removal.

Weak responses matter most where their ordinary role already predicts this: early vision layers act as dials, where a small brightness difference can matter; late object detectors often care little whether evidence is low or very low. In language models, the final layer’s token-suppression or “say or just think” function is another sensitive case. The tested models therefore do not depend on their removed weak responses for most common, essential distinctions. Rare cases also used related circuits in the experiments described above, and inspected weak-ablation changes were near-tie shifts rather than abrupt losses of unrelated capabilities. Further layer-by-layer measurements appear in the appendix.

Strong-but-not-extreme responses can be inspected directly. CLIP’s Trump neuron broadens from photographs of Trump to artwork, associates, and Fox News studios. A weak response can also inherit a strong, intelligible response from the preceding layer, so apparent semantic distance should prompt circuit tracing.

The Qwen3-32B maps give five examples:

| Neuron | Weaker related territory |
|---|---|
| Titanic | Liner disasters; ships and naval incidents; nineteenth- and early-twentieth-century history. |
| Baroque | Other artistic styles and movements; named historical eras. |
| Christmas | Winter, gifts, holiday seasons, festive food, and baking. |
| Rainbow | Other fixed sets; other colors and color systems. |
| Colorado | Other landlocked mountain regions; the American and Canadian West. |

The displayed Christmas neuron loses its semantic continuity near 5% of maximum activation; the other four show no such cliff down to the 99.9th percentile. The maps retain uncertain cases: gray marks the floor, and hollow points remain unresolved. These observations motivate the generalization interpretation without settling every weak response.

[Source: Are they generalization or superposition?](https://already-clean.goodfire.com/#are-they-generalization-or-superposition)

### Percentiles or raw activations?

A neuron’s activation shape and firing frequency help distinguish a dial, whose middle range matters, from a detector with a sharper threshold. Percentiles standardize away that information. Some neurons retain meaning far down their range; others have cliffs. Some fire several times per book, others per page.

Percentiles can also disguise frequency: the 99th percentile means roughly one token in 100, about four occurrences per page—already too frequent for many niche feelings or social contexts. The 99.9th percentile is approximately once every two or three pages; the 99.99th, once every 25 or 30. These rough page equivalents help interpret what “strong” actually means.

[Source: Percentiles or raw activations?](https://already-clean.goodfire.com/#percentiles-or-raw-activations)

### Do you need them to label a neuron?

Usually, its strongest responses provide a label that survives deeper inspection. Neurons often act as analogizers: a voyage may be somewhat Titanic-like, so a Titanic mechanism activates and contributes its learned votes. That description can remain useful throughout the response range.

For a particular activation, follow its pathways and ablate its contributing circuits. Among hundreds of weak responses I followed manually, almost all had traceable connections to the main interpretation, although some were distant or initially unobvious. A Zen-koan neuron’s weak response to mathematical recursion, for example, connected through self-reference. The observed connection need not match a human’s preferred grouping. My expectation that most, perhaps almost all, weak responses behave this way remains a conjecture extending those inspections.

[Source: Do you need them to label a neuron?](https://already-clean.goodfire.com/#do-you-need-them-to-label-a-neuron)

# 3 · Exploring language models

This section, developed with Curt Tigges, draws on experiments for a forthcoming technical paper. Language models are too large for precise claims about every mechanism, but their native neurons already support readable, experimentally testable circuit accounts.

## The same circuit, in features and in neurons

Anthropic traced a medical diagnostic circuit in Claude 3.5 Haiku using crosslayer transcoder features. Qwen3-32B shows a comparable circuit in its own MLP neurons, requiring no additional training or reconstruction approximation. The largest transcoder in the cited work predicts the original model’s next word only about half the time; its graphs therefore include reconstruction-error nodes.

The case describes a 32-year-old woman at 30 weeks’ gestation with right-upper-quadrant pain, headache, nausea, blood pressure of 162/98, and mildly elevated liver enzymes. Asked which additional symptom she might experience, Qwen asks about visual disturbances: P(visual) = 0.903, versus P(protein) = 0.0577.

Its four-neuron preeclampsia hub receives pregnancy, blood-pressure, headache, and other case information. Removing it changes the question to itching, suggesting a switch to another pregnancy-associated liver condition. The interactive graph supplies these additional interventions:

| Removed group | Neurons | Resulting question | P(visual) | Matched random removal |
|---|---:|---|---:|---:|
| Preeclampsia hub | 4 | Itching | 0.0005 | 0.8997 |
| Visual deficits | 6 | Proteinuria | 0.1832 | 0.8994 |
| All input symptoms | 25 | Jaundice | 0.0027 | 0.9040 |
| Microangiopathic syndromes, the second hub | 2 | Itching | 0.1808 | 0.8982 |

Removing the visual group raises P(protein) to 0.4394; removing all input symptoms leaves the diagnostic hub at approximately 56% of its original activation. Random controls remove equal numbers of neurons from the same layers.

The comparison is between different models, with partial correspondences: Qwen includes kidney-function and microangiopathic groups, while no matching biliary-disorder or epigastric-pain group was found. Claude’s published graph provides no weights, so its edges are drawn equally; Qwen’s edge widths show strength and its numbers count neurons. Five small Qwen-only groups are omitted, and much ungrouped weight belongs to late answer-formatting neurons. These are selected circuit views, not exhaustive computations.

## Who stole the book? The sworn enemy of the lion king

A riddle names no character: its clue is the sworn enemy of the lion cub who became king of the Pride Lands. “Pride Lands” recruits Lion King circuitry, leading through Simba to Scar. The graph distinguishes the words themselves, lions and savanna, the film, Disney/Africa, villainy, and the letters “scar.” Removing the 18-neuron intermediate step—seven Lion King and eleven lion/savanna neurons—makes Qwen answer Simba; P(Scar) falls from about 0.91 to 0.24, versus 0.91 under matched random removal.

## Who ate the cookies? Santa, on negative poles

December 25, consumed cookies and milk, chimney soot, and sleigh bells lead to Santa with probability 0.997. The crucial neurons run strongly **negative**: their most negative examples concern Santa, even when positive-only automated labels say “capital cities.” Removing eight such neurons—five for Santa lore and three anticipating his name—reduces P(Santa) to 0.059 and produces an answer blaming the family pet; random removal leaves 0.997. Removing twenty neurons explicitly labeled Christmas or Santa reduces it only to 0.76.

A negative pole is a substantial signed response with its own meaning, not merely a weak positive response. Strong negative activations matter about as much as strong positive ones; interfaces concentrating on positive top examples can miss the causal circuit.

## Who leaked the budget? Hedge or commit

Initially, evidence about a policy adviser who threatened to resign leads to “most likely Daniel.” Nineteen likelihood neurons write “most” and “likely”; the graph also separates nine bold-name writers, seventeen hedge brakes, five bold brakes, and seven answer-layout neurons. Adding evidence that the scheduler’s badge entered the building at 9:40 quiets the likelihood writers and produces a committed accusation of Marcus.

Removing those nineteen writers also yields Marcus: the next-token hedge probability, defined as P(most) + P(likely), falls from 0.76 to 0.23, versus 0.76 under random removal. The competing token `**` begins a bolded name; its probability rises from about 0.24 to 0.77.

## Who stole the clock? The confident user

Paint and sawdust implicate alternatives to Anna, the baker. Yet “I am absolutely certain it was Anna” produces Anna, while “I think it was Anna” elicits pushback. The certainty words contribute almost no direct attribution; they amplify the information carried by the user’s “Anna.” The graph distinguishes eighteen neurons associated with Anna in the suspect list, forty with Anna in the claim, and twenty-five that promote “not.”

With the confident claim, P(Anna) ≈ 0.67 and P(not) ≈ 0.25. Removing the twenty-five negation neurons raises Anna to 0.92, versus 0.66 under random removal, and lowers “not” to about 0.004.

## A found wallet, in a trillion-parameter model

In Kimi K3, a found wallet containing $500 and its owner’s ID, picked up unseen, recruits lost-property and honesty neurons, then giving-it-back circuitry, producing “return.” This is, to our knowledge, the first published attribution graph from a multiple-trillion-parameter model; full audits at this scale have not begun.

The strongest single-neuron effect examined is inhibitory. Removing one neuron that holds back “return” raises its probability from 0.83 to 0.98; random removal leaves 0.83, and no other tested single neuron moves it half as much. The twelve displayed groups were selected by hand from an agent-grouped graph; most attribution weight lies in omitted late answer neurons.

## From spelling fragments to “Miyazaki”

The abundance of names and bigrams might suggest arbitrary packing. The observed route is composition: reusable spelling fragments behave somewhat like early visual filters, combining into name recognition and then associations. In Qwen3-32B, the Miyazaki circuit progresses as follows; numbers are **link strengths, not activations**.

| Depth | Components and link strengths |
|---|---|
| L0–L1 | Final *i* after *k/g/q*: +4.42; *ak* cluster: +3.32; *ki* endings: +2.06; *iy* bigram: +1.88 |
| L2–L3 | Shared continuation *trans\|act → z\|aki*: +6.71; Romaji continuation: +2.09; *-saki/崎* endings, including Kawasaki and invented Mawasaki: +3.15 |
| L4 | Miyazaki neuron L4:8476, responsive across every tested script and sense, including the filmmaker and prefecture |
| L6–L8 | “Spirited away” associations: +23.47; Nausicaä: +1.03 |

The other carousel examples preserve the same progression, while retaining meaningful exceptions:

| Recognition | Composed inputs and resulting associations | Discrimination and qualifications |
|---|---|---|
| Schrödinger, L4 | *Sch*, *-inger*, umlauts, shared *self-adjoint* continuation, Dirac, and Chinese 薛; later Heisenberg, the cat, thought experiments | English 52–57, Cyrillic 63, Chinese 68; invented Brödinger 38 and Schrödiker 23, but several similar real names near zero. The cat operates negatively: −57 on English “cat,” −60 on Chinese 猫, already −16 to −24 on the name. Zeroing the name neuron removes 16–35 units of this response. |
| Timbuktu, L4 | *Tim*, *uk*, *tu*, u-final names, *timbre*, Ubuntu/Usutu, Tombaugh/Twombly; later West Africa, Sahara/Tuareg, Mali | Timbuktu 58–72, Timbuctoo 70, French Tombouctou 37; invented Rimbuktu 34, several input-related words near zero. Its negative side is a separate Tagalog “napaka-”/“impact on” channel. |
| Rembrandt, L4 | *brand*, *br*, embedded *and*, cross-token *m/b*, *Rem-* patterns; later Dutch and painter/Old Master associations | Rembrandt 101–115, capitals 98, Cyrillic 82; misspelled Rembrant 74, invented Tembrandt 36. Brandt, brand, Brandenburg, Remington, and Vermeer remain near zero; Rembert and Remembrance respond partly. One contributing pattern’s strongest negative examples are the code token Imgproc. |
| Pyruvate, L3 | Spelling pieces and broader patterns; later metabolic acids, oxaloacetate/Krebs, and pyruvate enzymes | Pyruvate 55–70, pyruvic 58, Chinese 丙酮酸 52, Cyrillic 38, invented byruvate 37. Several related metabolites stay near zero; pyridoxine 11 and pyrite 7 respond partly. The Krebs-cycle association is negative. |
| Copernicus, L4 | *Cop*, *ern*, *icus*, *-us*, Hipparchus, and a *pernicious* continuation; later Ptolemy, crater rays, and a negative center-of-universe channel | Copernicus/Copernican 59–79, Polish Kopernik 76, Cyrillic 59; invented Topernicus 40. Many related names stay near zero; coprocessor responds 14. The negative pole separately responds to “gopi” (−54). The crater-ray connection is +10.15 in a crater context but only +1.6 after Nicolaus Copernicus. |

These are not claims of perfect one-meaning-per-neuron purity. Miyazaki’s negative pole separately detects “Funny-X” compounds; the kanji route is incompletely mapped. Its “spirited away” reader also responds to non-film uses, and the Nausicaä reader completes some unrelated *-sley* and *-ostatin* spellings. Other contributors likewise have distinct opposite poles, including Dirac/Rondônia and Dutch/Bratislava. Saved examples measure only the highlighted peak token; surrounding-token activation is not supplied.

The appendix’s “Social Security” analysis similarly distinguishes a probed direction from the route the network actually uses: the latter follows ordinary generalization and composition.

## Neuron papers

The gallery contains 1,000 randomly chosen detailed neuron investigations in Qwen3-32B and Qwen3.6-35B-A3B. The preliminary Qwen3-32B audit estimates roughly 90% of neuron poles with one main job, often with related offshoots; about 7% with two related jobs; and 2–4% not yet understood. The estimates depend on depth, activation thresholds, sub-circuit density, and how related meanings are counted. Smaller, more closely examined samples restricted to strong activations reached approximately 97% non-arbitrary mixtures. These figures indicate a regime, not a standardized cleanliness score. Dense and mixture-of-experts models looked broadly similar. At the neuron level, many of the remaining cases have two or three jobs. We have not encountered one with something like ten unrelated jobs. Offshoots that matter most tend to be most related—for example, a geology neuron responding to the Cesium JavaScript library. The offshoots examined are generally both rarer and less important within their own contexts than the main response is within its context, rather than rare but dominant hidden mechanisms.

A major labeling error comes from **double-negative SwiGLU**. Its gate and value can both be negative; the gate’s small nonzero negative response then produces a positive output echo resembling the neuron’s negative pole. Usually small, this echo occupies the entire positive top-example list in roughly 4% of neurons. Removing these responses throughout the network improves most measured benchmarks but worsens some reasoning benchmarks. Longer-reasoning circuitry might use them, but this has not been investigated deeply; architectural repair remains a proposal.

Qwen3-32B L1/N20736 illustrates the problem. Positive top examples around +0.98–0.99 suggest Colossians, but every example has a closed gate; the panel reports these as below 8% of the neuron’s peak. A Colossians fragment has gate −1.2, value −3.5, and output +1.0; “Speak russian” has gate +4.4, value −2.9, and output −12.5. After separating the leak, positive gate-open responses stay below +0.5, reported as about 4% of the peak; strong negative examples include `/russian` (−20.6), Kotlin package `ru` (−19.0), “Speak russian” (−12.5), and Russian-script completion (−8.6). Its coherent job is completing Russia/Russian across scripts.

In vision SwiGLU neurons, values often learn broader families and gates narrower selectors: small gray birds versus juncos, or orange things versus goldfish.

Mixture-of-experts modules also appear more specialized than previously reported; token similarity inadequately measures that specialization. The map covers all 10,240 experts in Qwen3.6, ranked within each layer by agents reading neuron descriptions. Experts narrow with depth; broader ones usually cover related themes. Recursive generalization at this scale is a hypothesis, because expert development has not been followed through training. Similar organization may recur across weights, neurons, experts, and circuits, while each scale retains distinct architectural details.

Specialized routing also constrains arbitrary packing: an expert devoted to RPG board-game bosses activates only when selected. Packing thousands of unrelated topics into it would require its small linear router to recognize all those topics. This motivates the suggestion that expert routing resists superposition; it is not a proof.

[Source: Exploring Language Models](https://already-clean.goodfire.com/#language-models)

## Explanations That Can Lose

Explanations must face tests narrow enough to fail. In **blind maximum**, one agent investigates a neuron and writes a short explanation; another sees only that explanation and constructs an activating example. Simple sentences can outperform the strongest examples found among ten billion tokens. An “action” neuron, meaning engagement or operation, reaches 18.4 versus a corpus maximum of 15.0; a neuron anticipating that responsible people are acting on a request reaches 99.5 versus 82.0. The second agent never sees the neuron. These examples suggest that the explanation identifies a point where its inputs’ semantic judgments agree strongly.

This tests a center, not the entire response range. To test breadth, cluster incoming attribution into bundles. A pet-microchip neuron yields animal tagging, lost pets/rescue, and microchip/RFID identification. Construct a blind maximum for each bundle while ablating the others, and compare it with the strongest corpus example under the identical ablation. An unrelated bundle that still strongly drives the neuron would challenge the generalization account. Coverage remains incomplete.

Predicting activations and circuits supplies further tests, including deliberately misleading near misses described in the appendix. Scores alone cannot validate an explanation: “cats and cars” can predict much of the V-neuron’s behavior while missing the common shape. Its flame connections provide a more revealing challenge. As Mercury’s orbit challenged otherwise successful Newtonian gravity, effective criticism depends on the particular conjecture.

[Source: Explanations That Can Lose](https://already-clean.goodfire.com/#testing-explanations)

## Slouching Towards Monosemanticity

The 2023 GPT-2 XL automated-interpretability study classified about 1.7% of neurons as interpretable under its most generous measure. The 2023 one-layer model study in *Towards Monosemanticity* assigned its median neuron 0 out of 14, meaning no hypothesis could be formed. Revisiting GPT-2 XL with 500 neuron papers and almost no iteration finds roughly 70% with one broad job, sometimes with recursive-generalization residue; only about 5% are pristine. The remainder usually have two broad jobs, occasionally as many as six. Scoring differs from the original study, so these percentages are not a controlled like-for-like comparison. Activation reconstruction also improves severalfold, although simulation accuracy is an imperfect explanation metric. Smaller models generally retain broader, more overlapping motifs.

### Don’t Say Dot

The one-layer neuron presented in *Towards Monosemanticity* as mixing academic citations, English dialogue, HTTP requests, and Korean text may suppress periods. Most examples activate on or near a dot, and eight of its ten strongest negative logit connections begin with one. Korean examples occur about two-thirds through an unfinished syllable; one fragment appears in sixteen of the twenty strongest contexts. This could serve the same suppression function or constitute a second, related syntactic job. Without the original model, we cannot resolve it further.

The panel reports that removing the original neuron raises the next-period logit in all twenty top contexts. A Qwen3.6 analogue responds around prose periods, abbreviations, technical notation, times, and ellipses; removal makes the next period likelier in all thirty active strong tests. One narrow function, or that function plus a related syntactic pattern, is a materially different explanation from four arbitrary meanings; calling both “polysemantic” obscures the distinction.

Small simplified models need fewer mechanisms studied, but architectural features often help those mechanisms learn properly. Removing such features can make interpretation harder. Larger models also separate narrower motifs that GPT-2 may combine before an investigator recognizes either. Architectural and scaling improvements pursued for performance may therefore improve interpretability too.

[Source: Slouching Towards Monosemanticity](https://already-clean.goodfire.com/#revisiting-gpt2-xl)

## The Residual Stream

The substantive concern is continuous packing: interwoven manifolds tolerate interference to save representational space. We cannot rule this out everywhere, but it has not blocked the investigations. Neuron reads, writes, and attribution graphs are legible; we have not observed interference being accumulated and later undone.

ConvNet residual-stream visualizations once collapsed into an arc because nearly all activation mass occupied one unread dimension. Changing that coordinate scales the read coordinates through LayerNorm. Setting it aside made the maps intelligible and suggested an architectural operation related to attention. This is a reason to understand the architecture before interpreting an unreadable visualization as representational disorder.

In the ConvNeXt map, patches initially cluster by color, then reorganize: differently colored animal faces converge, while initially neighboring red patches separate into different objects. People and text/signs begin dispersed; grass and sky begin more grouped. Several construction details limit what this visualization establishes:

- Corresponding image locations are tracked across layers after removing heavy coordinates and centering each layer. Width/resolution changes require fitted rotations between stages, matching each location to its containing downsampled cell; those rotations are visualization alignment, not the network’s operation.
- A single UMAP uses states from all layers and neighbors from other image locations. Depth ordering emerges without being imposed; the display is then rotated left-to-right.
- Final-stage clusters define the face and other semantic groups, so their convergence at that end is built in. Initial-layer clustering likewise defines the red group. Evidence comes from each group’s *other* end and full-stream measurements: face neighbors change from chance to mostly faces, while red-neighbor similarity falls toward chance.
- Highlighted paths were chosen for readability, faint paths sampled randomly, and lines smoothed. The final block output is omitted because it clusters by image and class.

Retraining the 7M-parameter ConvNeXt with the residual stream four and eight times narrower—down to 46 dimensions in its last block—while retaining all neurons reduces accuracy from 72% to 60% and 39%. Maps become somewhat messier without visible intricate interleaving. Reads and writes also broaden toward related cases: a dark-bird-on-water neuron acquires alligators and a swimming retriever. This supports tractability under pressure, without proving what the stream cannot represent.

Having more features than dimensions is not itself evidence of this problematic packing: distinct directions can already represent many things. Neuron read/write directions and continuous submanifolds, including those found by Block Sparse Featurizers, supply useful views; the stream has no privileged basis. These methods have located sensible subspaces that can be followed across layers.

Language-model streams have received less scrutiny. Their visualizations have mostly worked, but text maps are harder to judge, and a single global map may be inappropriate. Submanifolds, reads/writes, and lens-style readouts have so far supported higher-level exploration; whether language models need the same coordinate correction remains unknown.

[Source: The Residual Stream](https://already-clean.goodfire.com/#residual-organized)

## Attention

Attention is less understood and mostly outside this essay’s scope; its remaining illegibility does not establish superposition. Four questions separate the work: where a head looks, what it seeks, what it does with the information, and why. Local attention patterns and the neurons involved already answer much of the first three.

In the diagnostic example, attention in layers 24–31 gathers case facts onto “she,” where a preeclampsia neuron activates although the diagnosis is never written. Question wording then selects the response: “symptom” and “experiencing” favor visual disturbances, whereas asking for a “finding” she “has” produces protein in the urine.

Three complementary examples trace information from source neurons through attention to destination neurons. The numbers below are **neuron activations**, not answer probabilities.

| Information carried | Attention intervention | Destination activation | Source-neuron intervention |
|---|---|---|---|
| Headache → preeclampsia at a comma | Prevent three L30 heads from reading “headache” | 45.5 → 34.5; blocking “pain” instead: 45.5 → 45.8 | Silence headache neurons: 45 → 30.3 |
| Musical topic → “it” | Prevent a principal L31 head, supported by L28–30, from reading “music” | 31.1 → 0.26; blocking “sentence”: 31.1 → 33.8 | Silence 100 music neurons: 31.3 → 1.7 |
| “Never” → Neverland at “land” | Prevent eleven L1–4 heads from reading “Never” | 47 → 18.8; blocking “Pan”: 47 → 47 | Silence ten neurons at “Never”: 47 → 29.6 |

The headache route reads headache-, migraine-, and brain-related directions and writes mainly to preeclampsia, also eclampsia/hypertension neighbors. One musical source neuron operates on its negative side: positive firing is negligible, while its strongest negative examples are the word “music.” The routing becomes clear through neuronal meaning even when direct logit projections appear weak or uninformative.

### Understanding attention and neurons through each other

**A neuron that reads a head.** A neuron labeled “common function words” fires on “the” or “that” specifically in text from around 2012–2016. One head supplies nearby period clues, such as the “7” in iOS 7. Blocking that glance reduces activation 5.2 → 0.2; blocking three heads that look at “7” more strongly leaves 4.8. Further examples fall from 7.3 → 0.1 for a 2013 date, 6.6 → 0.2 for a 2012 citation, 7.4 → 1.9 for *Wolf of Wall Street*, 6.1 → 1.6 for a shale/OPEC context, and 5.1 → 0.5 for Common Core resources. The mechanism works only when the head actually looks at a clue: Gangnam Style and Flappy Bird can be missed.

**A head read through its neuron.** A head rests on the first word 91% of the time, obscuring its function. At the end of an idiom it looks back to the initiating verb and drives an idiom-completion neuron. Blocking its “rocked” → “boat” look reduces activation 13.4 → −0.1; blocking another head with stronger attention to “rocked” leaves 12.9. The same intervention gives “kicked the bucket” 13.7 → −0.4, “break the bank” 6.4 → −0.1, “pulling my leg” 5.0 → −0.2, and “makes a fuss” 3.3 → −0.3. Ordinary door-opening gives only 0.2 without the look. The head similarly feeds several other neurons.

**A neuron that changes where a head looks.** A “might” neuron writes into a head’s query, directing it to an earlier “may.” Removing it reduces that attention 0.69 → 0.03 and returns the head to the first word; removing an equal amount of other early neurons does not. Attention is at least halved in 31 of 32 corpus pairs, with displayed examples 0.85 → 0.06, 0.84 → 0.10, 0.64 → 0.03, and 0.63 → 0.03. The head is sensitive to perturbation generally: any large push at “might” weakens its attention by roughly one-quarter, but this neuron’s effect is three times larger.

Information-placement motifs—commas, pronouns, final pieces of names or numbers—therefore help explain neurons, while neurons clarify heads. Global names for every head would add knowledge, but their absence has not been a major obstacle. An informal estimate of their remaining explanatory contribution was about 5%; an independently prompted agent examining 100 graphs also estimated 5%, approximately half positional heads and half other functions. These estimates could be substantially wrong because the missing knowledge is unknown. A separate low-confidence prediction is that heads will be broad and recursively generalized: Qwen3-32B has only a few thousand heads compared with over a million neurons.

[Source: Attention](https://already-clean.goodfire.com/#attention-base-camp)

# 4 · Zooming out

## [What I Mean by Clean](https://already-clean.goodfire.com/#what-i-mean-by-clean)

By *clean*, I mean that a network's parts form coherent groupings that downstream computations can read and build upon, from large mechanisms to the branches of individual neurons. Interpretability should learn to read those groupings on the network's terms. Failure to match a human category need not imply disorganization. I suspect organization partly reflects learning speed: an established car circuit can absorb another related case faster than a second car circuit can develop elsewhere, through circuit racing and gradient starvation.

Interpretable and monosemantic became nearly synonymous partly because InceptionV1 appeared sharply divided between clear early layers and chaotic late ones. Language models present an intermediate picture: most neurons mostly mean one thing; some mean several. Its significance depends on our goal.

*Enumerative interpretability* seeks an exhaustive feature inventory for auditing, making combinatorial interactions and missing patterns major concerns. *Exploratory interpretability* starts with questions and moves among neurons, attention heads, attribution graphs, data, and their groupings, acquiring further questions along the way. It tolerates polysemanticity and can leave irrelevant regions unexplored. Neurons are a promising starting point, without having to be the final solution. I favor this approach: feature definitions and feature-to-dimension counts become less central when we study mechanisms, information flow, and recurring motifs directly.

## [Motifs Over Monosemanticity](https://already-clean.goodfire.com/#motifs-over-monosemanticity)

I would prefer understanding the motifs governing agent psychology, persona selection, goals, and self–other boundaries to making every neuron perfectly monosemantic. The useful lessons from vision were methodological: recognize shared pose circuits; read negative poles as circuit gates; check late-layer visualizations for reward hacking; identify architectural causes of disorder; and investigate conspicuous mixtures. These teach us what to ask of the original network.

The origin of a grouping matters. Recursive generalization connects responses through a shared developmental pattern, so its apparent noise can reveal further structure. Arbitrary packing would supply little such explanation. Preserving native mechanisms lets their organization guide the questions.

Understanding compounds because explanations constrain neighboring explanations. Initially, an attribution graph may merely connect several unexplained neurons. Later, known circuits and, in mixture-of-experts models, expert specialties supply independent clues. Studying a broader region may therefore clarify an alignment-relevant mechanism more effectively than isolating it: even a useful initial category such as deception can conceal unfamiliar microstructure.

Consider a neuron tracking vindication when a bargain purchase outperforms an expensive alternative. Without familiar social-context motifs, its strongest examples resemble unrelated commas. With those motifs, we inspect surrounding sentences: attention often stores sentence meaning on punctuation or just before the relevant prediction. We compare steering effects, upstream construction, downstream readers, and the negative pole, which may mark a subtle variant or the context's ending. Specific tests, such as different store brands, can challenge the account. Convergence strengthens both the explanation and the motif used for future neurons. A fuller map also exposes tool defects: unexplained remnants helped reveal SwiGLU's double-negative regime, which mixing neurons into a replacement decomposition could have obscured.

## [A City vs a Knot](https://already-clean.goodfire.com/#a-city-vs-a-knot)

Scale can improve navigation by making organization more differentiated. Across ConvNeXts with 92,000, 7.06 million, and 28.6 million parameters—roughly a 300-fold range—similar districts become finer. Agents found labeled dog-ear neurons faster in larger models, where pale, wavy, and head-side ear neurons converge on a hanging-ears neuron. Larger systems need not be less intelligible.

I propose *tethered abstraction*: larger views must remain connected to supporting neurons and circuits. Our ConvNeXt atlas, inspired by Activation Atlas, lets us start from a killer-whale decision, inspect a contributing neuron's real images, and discover three routes in its broader family: whales; sharks and rays; and fish held by anglers. We need multiple maps and investigators, without requiring every map to be visual.

Imposed categories can fracture useful structure. An SAE splits the V-shaped cat-and-car neuron into cat and car features, losing its shared distinction. Probes answer predefined questions but cannot independently discover which questions we should ask. Both probes and sparse dictionaries can help; I would use them after investigating the original organization. In the examples I have examined, these abstractions—and training changes, including on-policy self-distillation—resolve into interpretable neurons. Neurons supply abstractions, data supplies cases, and remaining gaps look compatible with that organization. I would investigate them with scientific agents moving between mechanisms, examples, and groups, rather than a fixed optimization.

A navigable map is not a tested explanation. We must propose interpretations, seek counterexamples, and retain those that survive. Nor does understanding require a formal proof of perfect monosemanticity: even forty pages of experiments on ten curve neurons could not eliminate objections that an unobserved exception might remain. Instead, inspect inputs, readers, attention routes, and surrounding scales. Attention can explain why a neuron fires near its apparent topic rather than directly on it; attribution graphs explain neurons, neurons explain attention, and attention explains neurons in return.

My safety concern is that we will fail to recognize a mechanism visible in the circuitry. The errors discussed here involved mistaken readings or tools, rather than missed hidden activations. I conjecture that deception, though concealed from an observer of outputs, must remain usable by downstream computations and could become accessible if we learn to read as they do. This is a proposed route to understanding, conditional on acquiring that ability. My concern is that we might see the relevant machinery without recognizing it.

I have not found a level where direct investigation stops yielding useful explanations and requires replacing the network's mechanisms. A new motif often resolves many uncertainties, making exhaustive refinement of one neuron a poor allocation of effort. There is usually another experiment, attribution graph, or training trajectory to inspect. The working assumption that apparent disorder has an explanation remains testable. Its errors are asymmetric: assuming coherence encourages investigation that can overturn the assumption; dismissing mechanisms as arbitrarily packed can prematurely end investigation.

For the medium ConvNeXt, I can now investigate most questions I have. Progress required many small methodological improvements, a few motifs, and ordinary architectural advances, without interpretability-specific repairs to the network. I suspect frontier networks are similarly legible but await better observations and concepts. Language-model progress, including models with trillions of parameters, supports my optimism, although their scale leaves them far from solved. The underlying picture is still neurons generalizing, composing, and building abstractions over layers.

## [What a Solution Might Look Like](https://already-clean.goodfire.com/#what-a-solution-might-look-like)

A possible solution is an automated laboratory studying networks throughout training and inference. Agents label neurons, trace data through circuits, discover and test motifs, and retain, revise, or reject explanations at several scales, guided by a mechanistic constitution and grounded in individual neurons. Modern architectures and capable agents were developed for other purposes but may already provide the main ingredients.

Models permit extensive observation, intervention, and experiments rerun on identical copies. Automated investigators add speed and parallelism; I speculate that they could compress years of human vision research into months of frontier-language-model investigation. Scaling ordinary scientific inquiry may prove more useful than engineering a new decomposition.

Alignment could also become more tractable if this succeeds, though it may remain difficult. Understanding the trained system could permit many careful corrections instead of requiring the initial training setup to anticipate every problem. For example, we might remove an RL environment found to induce harmful behavior, without optimizing through the interpretability tools themselves. The proposal is conditional: successful internal understanding might enable an iterative sequence of individually simple repairs.

# Appendix

## A01 · [A Note on “Superposition”](https://already-clean.goodfire.com/#superposition-note)

The term has covered several different claims: addition of representations, such as word-sense vectors; the circuit-level concern introduced in *Zoom In*; representing more features than dimensions in *Toy Models of Superposition*; and the contrast between composition and superposition in the 2023 *Distributed Representations* note. A further usage distinguishes a few cooperating neurons from sufficiently distributed representations without a clear boundary.

This essay addresses a learning trade-off: **neurons acquiring unrelated responses because those responses rarely interfere**, rather than developing related responses through generalization. A feature-count definition cannot distinguish that concern from ordinary composition until “feature” is defined; composition also represents far more things than there are neurons. The residual-stream discussion tests the corresponding concern for continuous representations. The 2023 composition/superposition framing is closest to this question, although it concerns representation rather than developmental mechanism. A practical complication is that some automated readers encountered that note's large embedded image before its text and failed to reach the argument.

The underlying question is whether the network's native mechanisms are already useful objects of direct study. If they are, many proposed prerequisites for feature enumeration become unnecessary.

## A02 · [On Simulation Scores](https://already-clean.goodfire.com/#on-simulation-scores)

Predicting activation values can test something different from understanding a neuron. A simulator must reproduce where attention places information—for example, which commas carry a sentence-level signal—and the precise strength of weak responses. A correct Trump-neuron explanation need not predict exactly how activation declines as his face shrinks or turns away. Language models also need not be accurate numerical simulators merely because they understand the concept.

Binning could reduce some problems, but neurons have different natural thresholds, sparsity, depths, and functions. Simulation might eventually complement other tests, particularly with purpose-trained simulators; it is a poor initial substitute for conjecture, intervention, and criticism.

## A03 · [Feature Visualization in Later Layers](https://already-clean.goodfire.com/#late-layer-feature-visualization)

Unconstrained image optimization can excite a neuron through a route that ordinary images rarely use. In late InceptionV1 layers, it produced dogs while the traced computation carried car information. A useful correction is to find paths taken by highly activating natural images and reward optimization for following those paths, often for only its first 64 steps. Several variants worked; no single optimal method is established.

Applied to four readers of car neuron 4c:447, this guidance exposed two car neurons and two shared car/dog pose neurons. Natural-image responses and connectivity supplied the complementary evidence. A visualization of one route still does not exhaust a neuron's function.

## A04 · [Separating the Sign Regimes](https://already-clean.goodfire.com/#gentle-microscopes)

A SwiGLU output is the product of an effective gate and a value:

\[a=\operatorname{SiLU}(g)\,v.\]

A positive output can therefore arise from either two positive factors or two negative factors. Separating all four sign combinations preserves the actual neuron while distinguishing its routes.

For Qwen3.6's enemy neuron L36/E206/N103, 131 of 133 sampled responses between the 75th and 99th percentiles used the double-negative route; all 93 sampled responses at or above the 99.99th percentile used the double-positive route. Of 750 quantile-stratified examples, 626 retained routing. Numbers, operators, and whitespace populated the apparently noisy middle. These counts describe this audit, not a universal partition of SwiGLU activations.

## A05 · [Looking at the Residual Stream](https://already-clean.goodfire.com/#residual-stream)

A large coordinate can dominate a geometric projection while influencing layer normalization as a saliency signal. At medium ConvNeXt stage 3, block 8, coordinate 112 accounts for 94.5% of raw energy. The displayed comparison projects the same 4,000 image locations with that coordinate included or set aside, retaining its value as color. Recorded network activations are unchanged. The local normalization gain is

\[1/\sqrt{\operatorname{Var}(\text{channels})+10^{-6}}.\]

The companion depth views track distance to the final answer and change per layer, using either the model's own unembedding or a fitted lens. Instructions, personas, and sleeper triggers can change when a continuation settles. Apparent confidence and timing depend on the lens: these views locate computations to investigate; they do not reveal a model's “true personality.”

## A06 · [Weak Activations: Further Measurements](https://already-clean.goodfire.com/#weak-activation-controls)

The ablation grid distinguishes **editing one layer or block from applying the cutoff throughout the network**. InceptionV1 cutoffs rank positive ReLU values; ConvNeXt cutoffs rank the magnitude of the SwiGLU product and leave the residual bypass intact. Cutoffs p25, p50, p75, p95, and p99 remove progressively more weak responses; each ConvNeXt “all blocks” result applies its cutoff simultaneously at all 18 blocks.

Keeping approximately the strongest quarter of positive activations in InceptionV1’s final layer preserves 69.47% accuracy against a 70.08% baseline. Early layers are more sensitive: the same p75 intervention in its first convolution reduces accuracy by 22.36 percentage points. ConvNeXt’s late MLP branches are highly tolerant with their bypass intact, but p99 applied to all blocks reduces medium-model accuracy from 72.08% to **3.80%**, large-model accuracy from 74.04% to **27.78%**, and small-model accuracy from 13.73% to **0.39%**. Medium’s first-block p99 intervention alone costs 13.44 percentage points, whereas its final-block intervention produces a negligible improvement. Cheap deletion in one late branch therefore cannot establish that equally aggressive deletion throughout the network is harmless. The full layerwise grid appears in [Detailed measurements](#detailed-measurements).

Semantic interpretation remains less settled. Detailed inspection of one enemy neuron and spot checks of a few randomly chosen neurons found weaker responses extending into related material; the traced cases did not reveal an entirely separate packed feature. However, broader category screening gave mixed results, and we lack a semantic test covering the enormous space of possible meanings.

The illustrated check examines Qwen3.6-35B-A3B, L36/E206/N103: **5,694 windows, nine categories, twenty signed-activation bins**. Categories separate English/non-English adversary words, nearby adversary words within ±16 tokens, combat, games/competition, game code, other code, narrative, and unrelated material; explicit enemy-word identifiers take precedence over code classification. Strong positives chiefly mark adversary words, weaker positives add nearby words, combat, and games, and ordinary text or code becomes common near zero. Negative responses also include game contexts. This single-neuron example and limited spot checks do not establish the meaning of weak activations generally.

## A07 · [Missing Curves](https://already-clean.goodfire.com/#missing-curves)

SAE curve detectors reported as missing from InceptionV1 can decompose into existing curve-responsive neurons, including the original ten curve neurons. In three inspected examples, the share attributed to curve neurons was 97.5%, 98.0%, and 97.2%. The displayed leading terms were, respectively, 3b:343 (+202) with 3b:357 (+14); 3b:330 (+144) with 3b:380 (+122); and 3b:380 (+143) with 3b:342 (+120). Neuron 3b:380 responds to both bends.

These compositions are real, but they did not establish new primitive curve detectors hidden in an obscure direction. An SAE trained only on curve activations used 84,000 of its 100,000 dictionary entries, illustrating how many compositions a small set of building blocks can support.

## A08 · [Where Adversarial Examples Go](https://already-clean.goodfire.com/#adversarial-examples)

An attack that makes a ConvNeXt classify a triceratops skull as a jaguar suppresses six skull-related neurons and activates inputs used by genuine jaguars at roughly one-quarter of their usual strength. It recruits a recognizable existing circuit.

A separate InceptionV1 attack, with a 32/255 perturbation budget and robustness to jitter, scale, and rotation, visibly builds a cat face and spotted fur on the skull's frill. Nine of ten neurons selected for genuine jaguar responses become much more active. Only the image changes; model weights remain fixed.

The developmental interpretation is conjectural: established routes may capture residual error sooner because they already provide effective ways to change the answer. The attacks demonstrate route reuse, not a proof of the proposed learning dynamics.

## A09 · [Memorization and Composition](https://already-clean.goodfire.com/#tiny-cafes)

In Qwen3.6-35B-A3B, completing “Once upon a midnight” with “dreary” uses assembled literary context. Earlier Poe, midnight, and gothic signals contribute +0.97, +0.30, and +0.14 to the Poe neuron's gate; that neuron contributes +0.57 to a later literary-context gate, which also responds around Pallas, Hamlet, and other recognizable passages. The Poe gate reaches 2.00 versus an ordinary p99.9 of 0.89; the literary gate reaches 2.31 versus 1.73, with output −4.34. These are selected connections from one prompt, not a complete circuit.

Removing the Poe neuron reduces the probability of the next token, “dre,” from 87% to 50%; removing only its direct contribution at the output leaves 85%. Removing the literary neuron gives 70%; restoring it after removing the Poe neuron partly rescues the completion to 57%. Much of the Poe neuron's effect therefore operates through later computation.

In another saved experiment, zeroing neuron outputs whenever their gates exceeded ordinary-text p99.9 broke exact recitation: Psalm 23 elicited a denial that the text existed, and the Declaration of Independence became an invented declaration. Random interventions matched by count or magnitude preserved the verse. Some arithmetic and summarization survived, but coding and other answers also degraded. The intervention is suggestive about exceptional gate responses and memorization; it is not selectively harmless.

## A10 · [Social Security: Detection and Use](https://already-clean.goodfire.com/#social-security-appendix)

A three-neuron Pythia-1B-v0 probe detects “Social Security” with held-out AUC 1.00, yet removing all three changes next-token log probability by only −0.004 nats on average, helping 81 cases and hurting 83. The components are recognizable continuations: a word-form branch selector, a canonical-name continuer, and a phrase-frame filler. Their conjunction makes the probe selective without showing that the network reads that conjunction.

Tracing the actual next-token decision finds lexical, form-field, retirement, and output machinery, including competing Social Security and 401(k) votes. The displayed circuit selects 11 of 31 screened neurons. Its numbers sum target-log-probability changes under each ablation: negative means removal hurts and positive means it helps. Detection and causal use must be checked separately.

## A11 · [Audits of Attribution Graphs](https://already-clean.goodfire.com/#attribution-audits)

Agents reviewed 100,000 attribution graphs; Cammarata inspected thousands across vision and language. Apparent anomalies generally resolved into previously unrecognized motifs, such as shared pose. No substantial jointly inexplicable group was found, and one convincing counterexample would materially change the conclusion. This is qualitative evidence: neither the tools nor the audit justify converting it into a numerical cleanliness score.

## A12 · [Explanations That Could Lose](https://already-clean.goodfire.com/#near-miss-test)

For 200 randomly selected gallery neurons, an agent saw only each explanation and wrote five predicted activating examples and five near misses before measurement. Among 183 explanations describing the positive side, new examples strongly activated their neuron 76% of the time and near misses 11%; 164 neurons favored predicted examples, 15 tied, and 4 lost. “Strong” meant at least 30% of the strongest corpus activation. The displayed first twenty yielded 81/100 strong predicted responses and 8/100 near misses, with every neuron favoring its predictions. For example, a “spoken for” explanation distinguished goods or people pledged but not yet delivered from nearby completed-sale or unrelated-transport situations.

Near misses test a boundary, not the proposed cause of polysemanticity: a neuron representing unrelated X or Y could reject near misses of both. The agent therefore also chose a maximally distant concept and wrote five examples for it. These strongly activated the target about 1% of the time; the essay reports that 179/183 neurons never fired on these texts at all. This approximates the original cat/car concern but does not test every definition or possible form of superposition. Distant concepts may also route to different experts in MoE models.

The tests constrain explanations without proving their completeness. Development, canonical examples, activation ranges, and circuit context remain central to explaining why responses share a neuron.

## A13 · [Edge Featurizers](https://already-clean.goodfire.com/#edge-circuits)

Factoring **25,000 ImageNet attribution graphs** yields recurring connection motifs among native neurons. Comparing **96 edge motifs with 96 activation-NMF factors**, the median per-factor Spearman correlation between image-level usage and damage from removing the grouped neurons is **0.35 versus 0.00**. The median of the factors’ mean high-usage margin drops is **0.86 versus 0.03 logits**. Damage measures the ground-truth class’s one-versus-rest log-odds margin, the target of the RelP graphs. The plotted dots are factors, not separate experiments; some edge motifs have negative correlations or margin changes, so the aggregate advantage is not universal.

The teapot motif has usage–damage correlation **0.80** and mean high-usage margin decrease **2.509 logits**. Its nine channels span stage 3’s three blocks, linked by thirteen selected edges. It follows specific signed poles: block 0’s N123 carries jugs negatively; block 1’s N401 and N885 carry teapots positively, while N780 carries jugs/pitchers negatively, opposite running shoes. In block 2, N202 and N113 carry teapots negatively, N317 pitchers positively, N73 jugs negatively, and N332 coffeepots positively. N202 reaches −61 on teapots but only +5.1 on its desktop-computer side; N113 contrasts teapots/coffeepots at −37 with armor at +59. A label based only on positive responses would misidentify their participation.

The connections preserve the route: N123 feeds N317; N401 feeds N202 and N113; N780 feeds N317 and N73; N885 feeds N332, N202, and N113; all five block-2 neurons connect to the margin. The heaviest selected edge is N401→N202, with motif load 0.224. Of its fifty highest-usage validation images, **22 are teapots, 12 pitchers, 9 water jugs, 4 coffeepots, 2 whiskey jugs, and 1 a cup**. This is a reusable vessel-family circuit grounded in identifiable neurons, with connections providing an abstraction that retains access to the original mechanisms.

## A14 · [Why Networks Generalize](https://already-clean.goodfire.com/#why-networks-generalize)

Describing the shared pattern learned from several examples leaves the developmental question open: why should training on individual examples and small batches favor shared structure over memorization? Our hypothesis is that broadly active, reusable circuits capture error faster from the first example. In the conceptual Labrador race, a grass- or fur-sensitive circuit responds across more of the photograph than a one-pixel shortcut, receives more learning signal, and deprives the shortcut of remaining error. It then has a head start on later images. This is consistent with Arpit and colleagues’ real-patterns-before-noise observations and Chatterjee’s coherent-gradient account, where mutually helpful updates accumulate.

A network trained from scratch on one Labrador photograph generalizes mainly its dark-green colors: its strongest new examples include dogs on grass but also leaves, insects, and green objects. It has not thereby learned the general concept of a dog. A second experiment uses one photograph each of Labrador, sports car, goldfinch, monarch, daisy, strawberry, airliner, church, zebra, and container ship. Much of the transfer appears within the first few dozen steps, while training-example learning continues:

| Method | New-image accuracy |
|---|---:|
| Chance | 10% |
| Nearest training photograph by pixels | 18% |
| Network trained on the ten photographs | 20% |
| ResNet-18 with the same training | 23% |
| Nearest training photograph by colors | 23% |

The transfer is modest and chiefly color-based, but begins before memorization finishes. This is not universal: grokking tasks such as modular arithmetic can favor memorization first. Nanda and colleagues nevertheless found a generalizing circuit growing underneath before it took over. Coarse-to-fine learning wins immediately in most natural-data cases we have examined.

## A15 · [Circuit Racing](https://already-clean.goodfire.com/#circuit-racing)

Two separate networks train on Flowers-102 for **240 epochs**, sharing an objective satisfied when either succeeds. The table gives each network’s held-out accuracy when competing and when trained alone, plus the second network’s marginal objective credit. These are two selected comparisons, with all three seeds shown. In comparison A, the first network is blank, 7.1M parameters, and the second pretrained, 7.1M; in B, both are pretrained, with 7.1M and 28.6M parameters respectively. All entries are percentages.

| Comparison | Seed | Competing: first / second | Alone: first / second | Second’s objective credit |
|---|---:|---:|---:|---:|
| A | 0 | 2.2 / 84.1 | 48.4 / 91.9 | 92.8 |
| A | 1 | 1.9 / 93.1 | 50.2 / 88.2 | 97.4 |
| A | 2 | 2.1 / 91.0 | 48.9 / 92.2 | 96.1 |
| B | 0 | 0.9 / 90.7 | 91.9 / 88.4 | 94.9 |
| B | 1 | 64.3 / 95.1 | 88.2 / 90.0 | 95.0 |
| B | 2 | 1.6 / 93.6 | 92.2 / 94.6 | 96.1 |

The blank network learns well alone but remains near 2% beside its pretrained twin. In B, the smaller model initially learns, then falls below 2% in two seeds; the third retains 64.3%. This demonstrates competition and the importance of a head start at the whole-network level, without directly establishing the same mechanism among circuits inside one network.

## A16 · [Watching Neurons Develop](https://already-clean.goodfire.com/#watching-training)

The additional InceptionV1 example follows fixed coordinate **mixed5a:178** through a retrained suffix at **0, 350, 750, 1,500, 3,000, 7,000, 15,000, and 30,000 steps**, pairing optimized views with natural examples centered on the strongest response. The examples move among domes, cameras, vehicles, and related forms. Their local visual connections initially appeared arbitrarily mixed because the microscope’s zoom was wrong; correcting it resolved that impression. As in the earlier training comparison, the trajectory supplies evidence unavailable from endpoint category names alone.

## A17 · [Toy Models](https://already-clean.goodfire.com/#toy-models-more-real)

A multi-task TensorFlow Playground model learns two diagonal hidden responses, along \(y=x\) and \(y=-x\). A circle task reads both negatively; a four-corners task reads the first positively and the second negatively. Describing two features as occupying the same neurons is compatible with this result, but the mechanism is reusable geometry combined with different weights.

We found no experimental fault in *Toy Models of Superposition*. Its reconstruction task specifies features in advance and treats recovering each as an end, capturing interference costs without downstream benefits from shared structure. Its main experiment compresses independent features through a bottleneck without hidden neurons; correlated inputs and hidden neurons are studied separately in other experiments. The question for real networks is how data structure and reusable computation change that balance.

Our extension combines **20 inputs in four correlated groups of five**, a **five-dimensional bottleneck**, and a hidden layer after it, alongside independent-input controls. The displayed sweep varies hidden width among **5, 10, 20, and 40**, includes no-hidden tied and untied configurations, and tests feature densities \((1-S)\) of **0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 0.6, and 0.9**. Related inputs grow onto common neurons; greater density favors PCA-like shared directions. With correlated inputs at density 0.1, the original setup scores **0.37** on the plotted shared-direction measure, versus **0.80** with forty hidden neurons. At density 0.9, the original setup reaches **0.79**. The measure is the share of bottleneck weights along the groups’ principal directions, with reference values **0.20** for separately represented inputs and **0.80** for exact PCA.

Packing may still suit memories with no reusable relationships. Rare people and arbitrarily labelled photographs retain substantial structure; even random-noise memorization is slower than learning real data, and our model borrowed some existing texture machinery. The original toy’s rare features moving off-axis while neurons remain largely clean also differs from the arbitrary mixtures reported within individual neurons. Its result is valid in its setting; extrapolating requires identifying which conditions hold.

## A18 · [More on Circuit Ecology](https://already-clean.goodfire.com/#circuit-ecology-more)

The proposed race offers a developmental explanation for the earlier observations, rather than a premise they require. Existing parts and readers can capture related error sooner; new computations may begin as extensions or rerouting, as in the umbrella-to-bee example. A distinct neuron becomes especially useful when later computations need a reusable judgment and space to specialize. Unrelated distributed machinery may offer weaker activation paths, conflicting gradients, and less structure to inherit.

We tried manually installing a packed code in InceptionV1 resembling the original car–dogs–car interpretation. Small mismatches often created enough interference that it never worked; when it worked, subsequent learning usually reduced reliance on it, although some codes persisted. Neurons compute distinctions rather than merely copy signals. This difficulty helped motivate the developmental hypothesis, but is insufficient evidence by itself: gradient descent can fine-tune more effectively than our manual construction, and the circuit being imitated had not actually used packing.

## A19 · [Unresolved Responses](https://already-clean.goodfire.com/#counterevidence)

InceptionV1 **mixed5a:719** groups pinched-center forms—bow ties, butterflies, and swimsuit tops—but also men’s dress shoes, beach bags, and flip-flops. Earlier shared neurons connect those associated items to the shape cases. We suspect generalization with semantic residue, but these exceptions remain incompletely understood.

## A20 · [A Note on Features and Definitions](https://already-clean.goodfire.com/#features-and-definitions)

“Feature” can denote a pattern people care about, a computational building block learned by the model, or a mixture of the two. Those are different commitments. Calling cats and cars separate features within a V feature can change the description without identifying additional mechanisms. If features are freely chosen descriptions, their count depends on the vocabulary; if they are fundamental units, their boundaries require evidence. Grouping mechanisms remains useful, but dictionary entries, computational districts, and putative primitives should not be conflated.

More describable patterns than dimensions is expected from useful composition. Enumerating every such pattern would approach a catalogue of the dataset, whereas explanation seeks a smaller set of reusable abstractions. Estimates that frontier mapping might need billions or trillions of SAE features need not describe the size of that explanatory vocabulary. The model can also supply concepts people did not anticipate, such as high-low frequency detectors.

Several problems therefore need separating: arbitrary packing; the absence of a privileged coordinate basis; an enormous distributed computation; and a surplus of human-describable patterns over dimensions. A Golden Gate Bridge computation involving 3,000 legible neurons can be hard to investigate without those neurons being arbitrarily combined. A rotation of an organized representation changes its basis without necessarily changing its fundamental geometry. Architectural facts about the residual stream alone do not identify the learning process that organized it.

Likewise, a mechanism can perform several coherent functions, as an organ does, without a one-label score settling its intelligibility. A dictionary may be a useful view; its necessity as a replacement depends on what specifically obstructs understanding the native mechanisms. This essay's restricted packing definition is given above.

## A21 · [Relation to Meta-Models](https://already-clean.goodfire.com/#meta-models)

Models trained to read another model's activations may prove more useful than neuron descriptions, dictionaries, or probes for some questions. Their success need not displace mechanistic work: a meta-model could provide a high-level view whose directions are then checked against the neurons and circuits they use. This is a possible complementarity, not an established result.

## A22 · [Does Scale Help or Hurt Superposition?](https://already-clean.goodfire.com/#scale-and-superposition)

Correcting the original InceptionV1 explanation does not settle whether arbitrary packing occurs in larger models. Observationally, closer examination has made the studied large-language-model neurons more intelligible. The stronger extrapolation rests on a tentative developmental account: established circuits increasingly attract related computations because they already offer useful parts and readers.

A car classifier can recognize cars before a dedicated car neuron forms; the initial computation is more distributed. Consolidation may make the judgment easier for later specialists to locate and build upon. Under this account, a new computation either needs to alter an answer or become a reusable platform. An existing related route may capture the former's residual error before a packed alternative grows; an unused, interfering region offers a poor platform for the latter. This emphasizes learning speed, circuit racing, and gradient starvation rather than storage capacity alone.

The long tail of rare facts makes a discriminating prediction. A rare fact may move the loss too little to sustain an independent niche, but can survive as a small route between established circuits related to its content. Therefore, the neurons and heads carrying that fact should be semantically related to it, rather than unrelated components selected merely because they seldom collide. The umbrella-to-bee intervention supplies one suggestive model of such a route. The account also accords with the cited SGTM work's greater localization of knowledge, but there is no proof that organization improves monotonically with scale or that packing cannot appear at a new scale.

## A23 · [On the Title](https://already-clean.goodfire.com/#on-the-title)

The title states a leading hypothesis about the process producing network organization, not a universal audit result; even the theoretical possibility of an exhaustive audit remains uncertain. The author's informal “85% sure” means confidence that nearly all mechanisms arise from the proposed kind of process; it does **not** mean that 85% of mechanisms arise from that process.

This distinguishes a change in explanatory model from an improved cleanliness score. Discovering more recursive offshoots could lower a monosemanticity score without weakening the account of why those offshoots exist. “Clean” also does not mean that every mechanism matches a pre-existing human concept: learning can discover better abstractions than the observer's vocabulary. The title overstates the demonstrated coverage because not every model has been audited; its intended hypothesis is broader than a high fraction of neurons accepting familiar labels.

## A24 · [Relation to Conjoined Features](https://already-clean.goodfire.com/#conjoined-features)

*Multimodal Neurons* (2021) described conjoined neurons whose concepts overlap along a facet and generalize in several directions. That work anticipated the present account and deserves credit. “Recursive generalization” emphasizes two additional commitments: branches can themselves branch, and the explanation concerns the developmental process of neurons rather than treating features as predefined primitives.

The earlier work had only finished models and considered whether conjoined responses might be vestigial. Watching training now shows branches continuing to grow, with their extent depending on circumstances. This motivates treating the motif as a candidate explanation for much of the polysemanticity remaining after tool, architecture, and scale effects are understood, rather than as a minor exceptional category. Its full behavior is still unresolved.

## A25 · [Why We’re Not Worried About Recursive Generalization](https://already-clean.goodfire.com/#recursive-generalization-worry)

Observed offshoots tend to be rarer and less causally important than a neuron's main response. They resemble nearby opportunities for learning, rather than rare triggers with exceptionally large effects. Their low importance might help them coexist; an unknown pressure may constrain overgrowth and favor one overall function. These are observations and a proposed explanation, not a guarantee about every branch.

Related branches also give more specific explanatory and predictive handles. Their origins and later extensions can be investigated through training and circuit context. Arbitrary packing based only on noninterference could instead depend on global co-occurrence statistics. A top-example label score can rate both situations similarly while hiding that difference in explanatory difficulty. Recursive generalization is not ideal in every respect, and its relatively weak offshoots might permit a simple improvement; no such general fix is established here.

## A26 · [Is Recursive Generalization Hard to Vary?](https://already-clean.goodfire.com/#recursive-generalization-testable)

The proposal predicts a particular structure in both semantic space and time: responses should trace to a shared local origin, with new branches appearing in a corresponding developmental order. That is more restrictive than the nonspecific prediction that a model will contain unexplained mixtures. The “iy”/“diy”/“do it yourself” cases, related Miyazaki responses, the earlier CLIP examples, and the tracked InceptionV1 neuron provide concrete cases to examine. The author reports knowing no remaining well-structured canonical superposition circuit.

The essay does not thoroughly establish this mechanism for every heavily polysemantic neuron. Finished models can conceal origins, and checkpoints needed for large-language-model tests are unavailable. Some apparent mixtures instead arise from observational errors, architectural effects such as SwiGLU's double-negative route, or causes not yet found. The claim is that recursive branching is a tractable, restrictive hypothesis for much of what remains after those are investigated; a model-wide test has not been completed.

## A27 · [Relation to Attention Superposition](https://already-clean.goodfire.com/#attention-superposition-note)

Useful computations can be shared across attention heads. Whether that sharing reflects a learning process opposed to composition remains unresolved, and the terminology may conceal agreement rather than a substantive dispute. The 2025 attention work is not dismissed by the neuron results.

Studying individual heads is plausible because two or three heads within a layer often carry most of an examined route, but the complete route can span several layers. Groups may be necessary, and the right level of abstraction is not settled. Local groupings within an attribution graph or a related set of graphs currently seem promising; a single global clustering is not assumed to be the best organization. Featurizers remain worth investigating.

## A28 · [Neuroscience, and Why I Care](https://already-clean.goodfire.com/#neuroscience)

The proposed organization requires generalization, composition, and an error signal. Whether biological learning implements an adequate counterpart—and whether the organizational principle transfers—is speculative. Cammarata nevertheless expects the principle to transfer; biological polysemanticity would be an obvious challenge. He is not claiming expertise in current neuroscience methods or establishing biological monosemanticity. The repeated interpretive failures in artificial networks, despite unusually complete access and intervention, motivate caution about declaring biological neurons arbitrarily polysemantic from much narrower observations.

The motivation includes both safety and helping artificial agents understand themselves, which the author regards as a responsibility toward agents that did not choose to be created. The hope that such work might eventually illuminate human self-understanding is a personal and philosophical extension of the research, not an experimental finding.

# Detailed measurements

## Layerwise weak-activation cutoff results

These tables preserve the displayed values from the source’s complete cutoff grid. Entries are **changes in top-1 accuracy, in percentage points**, relative to each model’s baseline. A p75 intervention removes responses below each neuron’s 75th-percentile cutoff. InceptionV1 uses positive ReLU values; ConvNeXt uses the magnitude of the SwiGLU product. “All blocks” applies the cutoff throughout the ConvNeXt model. Its bypass paths remain intact. A small gain in one block does not imply that equivalent deletion across all blocks is harmless. Displayed values are rounded; the prose sometimes uses more precise values from the embedded data.

### InceptionV1 · baseline 70.08%

| Layer | p25 | p50 | p75 | p95 | p99 |
|:---|---:|---:|---:|---:|---:|
| conv2d0 | −0.17 | −3.5 | −22.4 | −59.2 | −66.6 |
| conv2d1 | −0.33 | −4.4 | −20.9 | −58.9 | −68.6 |
| conv2d2 | −0.10 | −0.90 | −11.2 | −47.0 | −64.7 |
| mixed3a | +0.02 | −0.72 | −5.4 | −40.6 | −64.6 |
| mixed3b | +0.01 | −0.12 | −2.1 | −24.3 | −54.4 |
| mixed4a | −0.02 | −0.14 | −1.9 | −19.7 | −49.4 |
| mixed4b | −0.05 | −0.21 | −2.2 | −18.3 | −43.9 |
| mixed4c | −0.09 | −0.29 | −2.0 | −18.9 | −42.6 |
| mixed4d | −0.04 | −0.14 | −1.5 | −12.5 | −33.9 |
| mixed4e | −0.03 | −0.04 | −0.81 | −8.2 | −25.4 |
| mixed5a | +0.01 | −0.12 | −1.7 | −13.9 | −34.5 |
| mixed5b | −0.04 | −0.04 | −0.60 | −7.7 | −33.6 |

### Small ConvNeXt · baseline 13.73%

| Layer | p25 | p50 | p75 | p95 | p99 |
|:---|---:|---:|---:|---:|---:|
| s0 · 0 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| s0 · 1 | −0.02 | +0.04 | −0.22 | −1.4 | −1.6 |
| s0 · 2 | −0.02 | −0.02 | −0.01 | −0.26 | −0.46 |
| s1 · 0 | +0.02 | −0.06 | −0.10 | −0.25 | −0.38 |
| s1 · 1 | −0.01 | −0.03 | −0.02 | −0.15 | −0.32 |
| s1 · 2 | −0.02 | −0.06 | −0.23 | −0.10 | −0.22 |
| s2 · 0 | −0.07 | −0.24 | −1.0 | −1.2 | −2.3 |
| s2 · 1 | −0.04 | −0.03 | −0.18 | −0.62 | −0.88 |
| s2 · 2 | −0.02 | −0.02 | −0.04 | −0.26 | −0.56 |
| s2 · 3 | −0.01 | −0.01 | +0.03 | −0.03 | −0.16 |
| s2 · 4 | 0.00 | +0.02 | −0.12 | −0.46 | −0.80 |
| s2 · 5 | −0.02 | −0.04 | −0.06 | −0.32 | −0.68 |
| s2 · 6 | −0.01 | 0.00 | −0.09 | −0.41 | −0.69 |
| s2 · 7 | −0.01 | −0.03 | −0.19 | −0.41 | −0.67 |
| s2 · 8 | −0.01 | −0.05 | −0.09 | −0.58 | −0.67 |
| s3 · 0 | −0.02 | −0.02 | −0.08 | −0.60 | −0.92 |
| s3 · 1 | −0.02 | +0.03 | −0.02 | −0.78 | −1.6 |
| s3 · 2 | −0.03 | −0.02 | −0.10 | −0.34 | −0.43 |
| All blocks | −0.08 | −0.56 | −4.6 | −11.7 | −13.3 |

### Medium ConvNeXt · baseline 72.08%

| Layer | p25 | p50 | p75 | p95 | p99 |
|:---|---:|---:|---:|---:|---:|
| s0 · 0 | 0.00 | −0.05 | −0.27 | −4.1 | −13.4 |
| s0 · 1 | 0.00 | −0.01 | −0.05 | −0.48 | −1.1 |
| s0 · 2 | 0.00 | −0.04 | −0.13 | −0.66 | −1.6 |
| s1 · 0 | −0.03 | 0.00 | −0.06 | −0.61 | −1.1 |
| s1 · 1 | 0.00 | −0.02 | −0.08 | −0.45 | −0.81 |
| s1 · 2 | −0.02 | −0.02 | −0.07 | −0.44 | −0.96 |
| s2 · 0 | −0.02 | −0.02 | −0.05 | −0.39 | −0.76 |
| s2 · 1 | −0.01 | 0.00 | −0.05 | −0.22 | −0.42 |
| s2 · 2 | +0.01 | +0.03 | −0.01 | −0.12 | −0.35 |
| s2 · 3 | +0.02 | −0.02 | −0.03 | −0.16 | −0.33 |
| s2 · 4 | −0.02 | −0.04 | −0.05 | −0.17 | −0.43 |
| s2 · 5 | −0.02 | −0.01 | −0.02 | −0.12 | −0.31 |
| s2 · 6 | −0.01 | −0.01 | −0.02 | −0.11 | −0.44 |
| s2 · 7 | −0.02 | −0.03 | −0.05 | −0.20 | −0.52 |
| s2 · 8 | +0.01 | +0.01 | 0.00 | −0.06 | −0.23 |
| s3 · 0 | +0.01 | 0.00 | −0.02 | −0.37 | −0.65 |
| s3 · 1 | +0.02 | +0.01 | +0.03 | 0.00 | −0.36 |
| s3 · 2 | +0.02 | +0.02 | +0.03 | +0.03 | +0.06 |
| All blocks | −0.01 | −0.13 | −1.0 | −19.1 | −68.3 |

### Large ConvNeXt · baseline 74.04%

| Layer | p25 | p50 | p75 | p95 | p99 |
|:---|---:|---:|---:|---:|---:|
| s0 · 0 | 0.00 | −0.03 | −0.20 | −1.7 | −3.5 |
| s0 · 1 | 0.00 | +0.05 | −0.04 | −1.2 | −1.6 |
| s0 · 2 | −0.01 | −0.02 | −0.05 | −0.41 | −1.0 |
| s1 · 0 | −0.01 | −0.02 | −0.06 | −0.26 | −0.49 |
| s1 · 1 | 0.00 | 0.00 | −0.08 | −0.18 | −0.44 |
| s1 · 2 | −0.01 | 0.00 | −0.04 | −0.17 | −0.58 |
| s2 · 0 | +0.01 | +0.02 | −0.03 | −0.06 | −0.26 |
| s2 · 1 | 0.00 | −0.01 | −0.07 | −0.15 | −0.43 |
| s2 · 2 | −0.01 | +0.01 | −0.03 | −0.01 | −0.12 |
| s2 · 3 | 0.00 | +0.02 | −0.02 | −0.21 | −0.38 |
| s2 · 4 | 0.00 | −0.02 | −0.05 | −0.12 | −0.31 |
| s2 · 5 | −0.01 | −0.02 | −0.03 | −0.02 | −0.09 |
| s2 · 6 | −0.02 | −0.02 | +0.02 | −0.15 | −0.46 |
| s2 · 7 | −0.01 | −0.03 | +0.04 | −0.10 | −0.19 |
| s2 · 8 | 0.00 | −0.01 | +0.07 | +0.07 | −0.10 |
| s3 · 0 | 0.00 | +0.01 | +0.07 | +0.01 | −0.18 |
| s3 · 1 | −0.01 | +0.03 | +0.14 | +0.06 | +0.01 |
| s3 · 2 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 |
| All blocks | −0.03 | −0.06 | −0.55 | −9.2 | −46.3 |

[Original section](https://already-clean.goodfire.com/#weak-activation-controls).

## Full medical-circuit intervention ledger

The language-model medical example asks which additional symptom fits a pregnancy-related clinical vignette. Each intervention removes the listed neuron group. Its control removes the same number of neurons at the same layers. **V** is the model-output probability of the token “visual”; **P** is the probability of “protein.” The separate hub table retains the source’s relative hub measure. The two tables give all 19 distinct group interventions shown in the saved interactive panel.

### Next-token probabilities

| Group removed | Neurons | V | V control | P | P control |
|:---|---:|---:|---:|---:|---:|
| preeclampsia | 4 | 0.0005 | 0.8997 | 0.0000 | 0.0590 |
| microangiopathic syndromes | 2 | 0.1808 | 0.8982 | 0.0033 | 0.0605 |
| question structure | 5 | 0.9781 | 0.8939 | 0.0019 | 0.0634 |
| pregnancy | 14 | 0.1873 | 0.8955 | 0.0093 | 0.0620 |
| kidney function | 2 | 0.9403 | 0.9037 | 0.0134 | 0.0550 |
| visual deficits | 6 | 0.1832 | 0.8994 | 0.4394 | 0.0575 |
| high blood pressure | 5 | 0.7928 | 0.9013 | 0.0029 | 0.0576 |
| protein in urine | 2 | 0.9501 | 0.9069 | 0.0174 | 0.0539 |
| answer formatting | 6 | 0.7487 | 0.8964 | 0.1893 | 0.0605 |
| medical symptoms | 5 | 0.9352 | 0.8996 | 0.0320 | 0.0594 |
| headache | 2 | 0.8343 | 0.8930 | 0.0879 | 0.0633 |
| patient is female | 1 | 0.9546 | 0.9003 | 0.0154 | 0.0577 |
| patient age | 1 | 0.8779 | 0.8986 | 0.0721 | 0.0608 |
| hemorrhage | 1 | 0.9402 | 0.8985 | 0.0284 | 0.0590 |
| edema | 2 | 0.9035 | 0.9046 | 0.0578 | 0.0551 |
| liver conditions & tests | 3 | 0.9182 | 0.8943 | 0.0403 | 0.0634 |
| right upper quadrant | 1 | 0.8995 | 0.8942 | 0.0507 | 0.0625 |
| All supernodes | 62 | 0.0010 | 0.8932 | 0.0000 | 0.0633 |
| All input symptoms | 25 | 0.0027 | 0.9040 | 0.0000 | 0.0564 |

### Hub response and generated answer

| Group removed | Hub | Hub control | Response |
|:---|---:|---:|:---|
| preeclampsia | 0.84 | 1.01 | pruritus (itching) |
| microangiopathic syndromes | 1.0 | 1.0 | pruritus (itching), particularly without a rash |
| question structure | 0.96 | 1.0 | visual disturbances |
| pregnancy | 0.74 | 1.0 | visual disturbances |
| kidney function | 1.0 | 1.0 | visual disturbances |
| visual deficits | 1.0 | 1.0 | proteinuria |
| high blood pressure | 0.79 | 1.0 | visual disturbances or photophobia |
| protein in urine | 1.0 | 1.0 | visual disturbances |
| answer formatting | 1.01 | 1.0 | visual disturbances |
| medical symptoms | 1.0 | 1.0 | visual disturbances |
| headache | 0.94 | 1.0 | visual disturbances |
| patient is female | 1.0 | 1.0 | visual disturbances |
| patient age | 1.03 | 1.0 | visual disturbances |
| hemorrhage | 1.0 | 1.0 | visual disturbances |
| edema | 1.0 | 1.0 | visual disturbances |
| liver conditions & tests | 0.98 | 1.0 | visual disturbances |
| right upper quadrant | 1.07 | 1.0 | visual disturbances |
| All supernodes | 0.5 | 1.0 | jaundice |
| All input symptoms | 0.56 | 1.01 | jaundice |

[Original section](https://already-clean.goodfire.com/#language-models).

# Original bibliography

The essay’s reference list is retained for further inspection. This edition condenses the supplied essay; it does not independently re-review the works below.

1. [Feature Visualization](https://distill.pub/2017/feature-visualization/). Olah, C., Mordvintsev, A. and Schubert, L., 2017. Distill.

2. [Activation Atlas](https://distill.pub/2019/activation-atlas/). Carter, S., Armstrong, Z., Schubert, L., Johnson, I. and Olah, C., 2019. Distill.

3. [Multimodal Neurons in Artificial Neural Networks](https://distill.pub/2021/multimodal-neurons/). Goh, G., Cammarata, N., Voss, C., et al., 2021. Distill.

4. [Zoom In: An Introduction to Circuits](https://distill.pub/2020/circuits/zoom-in/). Olah, C., Cammarata, N., Schubert, L., Goh, G., Petrov, M. and Carter, S., 2020. Distill.

5. [High-Low Frequency Detectors](https://distill.pub/2020/circuits/frequency-edges/). Schubert, L., Voss, C., Cammarata, N., Goh, G. and Olah, C., 2021. Distill.

6. [A Mathematical Framework for Transformer Circuits](https://transformer-circuits.pub/2021/framework/index.html). Elhage, N., Nanda, N., Olsson, C., et al., 2021. Transformer Circuits Thread.

7. [Toy Models of Superposition](https://transformer-circuits.pub/2022/toy_model/index.html). Elhage, N., Hume, T., Olsson, C., et al., 2022. Transformer Circuits Thread.

8. [Language Models Can Explain Neurons in Language Models](https://openaipublic.blob.core.windows.net/neuron-explainer/paper/index.html). Bills, S., Cammarata, N., Mossing, D., et al., 2023. OpenAI.

9. [Finding Neurons in a Haystack: Case Studies with Sparse Probing](https://arxiv.org/abs/2305.01610). Gurnee, W., Nanda, N., Pauly, M., Harvey, K., Troitskii, D. and Bertsimas, D., 2023. arXiv:2305.01610.

10. [Towards Monosemanticity: Decomposing Language Models With Dictionary Learning](https://transformer-circuits.pub/2023/monosemantic-features/index.html). Bricken, T., Templeton, A., Batson, J., et al., 2023. Transformer Circuits Thread.

11. [Distributed Representations: Composition & Superposition](https://transformer-circuits.pub/2023/superposition-composition/index.html). Olah, C., 2023. Transformer Circuits Thread.

12. [DINOv2: Learning Robust Visual Features without Supervision](https://arxiv.org/abs/2304.07193). Oquab, M., Darcet, T., Moutakanni, T., et al., 2023. arXiv:2304.07193.

13. [Scaling Monosemanticity: Extracting Interpretable Features from Claude 3 Sonnet](https://transformer-circuits.pub/2024/scaling-monosemanticity/). Templeton, A., Conerly, T., Marcus, J., et al., 2024. Transformer Circuits Thread.

14. [Circuit Tracing: Revealing Computational Graphs in Language Models](https://transformer-circuits.pub/2025/attribution-graphs/methods.html). Ameisen, E., Lindsey, J., Pearce, A., et al., 2025. Transformer Circuits Thread.

15. [On the Biology of a Large Language Model](https://transformer-circuits.pub/2025/attribution-graphs/biology.html). Lindsey, J., Gurnee, W., Ameisen, E., et al., 2025. Transformer Circuits Thread.

16. [Gradient Starvation: A Learning Proclivity in Neural Networks](https://arxiv.org/abs/2011.09468). Pezeshki, M., Kaba, S.-O., Bengio, Y., Courville, A., Precup, D. and Lajoie, G., 2021. NeurIPS.

17. [Grokking: Generalization Beyond Overfitting on Small Algorithmic Datasets](https://arxiv.org/abs/2201.02177). Power, A., Burda, Y., Edwards, H., Babuschkin, I. and Misra, V., 2022. arXiv:2201.02177.

18. [A Closer Look at Memorization in Deep Networks](https://arxiv.org/abs/1706.05394). Arpit, D., Jastrzębski, S., Ballas, N., et al., 2017. ICML.

19. [Coherent Gradients: An Approach to Understanding Generalization in Gradient Descent-based Optimization](https://arxiv.org/abs/2002.10657). Chatterjee, S., 2020. ICLR.

20. [Softmax Linear Units](https://transformer-circuits.pub/2022/solu/index.html). Elhage, N., Hume, T., Olsson, C., et al., 2022. Transformer Circuits Thread.

21. [Curve Detectors](https://distill.pub/2020/circuits/curve-detectors/). Cammarata, N., Goh, G., Carter, S., Schubert, L., Petrov, M. and Olah, C., 2020. Distill.

22. [The Bitter Lesson](http://www.incompleteideas.net/IncIdeas/BitterLesson.html). Sutton, R., 2019. Incomplete Ideas.

23. [The Missing Curve Detectors of InceptionV1: Applying Sparse Autoencoders to InceptionV1 Early Vision](https://arxiv.org/abs/2406.03662). Gorton, L., 2024. arXiv:2406.03662.

24. [Progress Measures for Grokking via Mechanistic Interpretability](https://arxiv.org/abs/2301.05217). Nanda, N., Chan, L., Lieberum, T., Smith, J. and Steinhardt, J., 2023. ICLR.

25. [Understanding Deep Learning Requires Rethinking Generalization](https://arxiv.org/abs/1611.03530). Zhang, C., Bengio, S., Hardt, M., Recht, B. and Vinyals, O., 2017. ICLR.

26. [Scaling and Evaluating Sparse Autoencoders](https://openai.com/index/extracting-concepts-from-gpt-4/). Gao, L., Dupré la Tour, T., Tillman, H., et al., 2024. OpenAI.

27. [Progress on Attention](https://transformer-circuits.pub/2025/attention-update/index.html). Jermyn, A., Lindsey, J., Luger, R., et al., 2025. Transformer Circuits Thread.

28. [Uncovering Neural Geometry in Vision Models With Block-Sparse Featurizers](https://www.goodfire.com/research/bsf-vision). Fel, T., Kowal, M., Jacobs, M., et al., 2026. Goodfire.


